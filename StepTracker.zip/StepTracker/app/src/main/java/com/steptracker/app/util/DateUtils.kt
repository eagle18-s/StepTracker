package com.steptracker.app.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

object DateUtils {

    private val dayKeyFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val displayFormat = SimpleDateFormat("d MMM, yyyy", Locale("az"))
    private val displayTime = SimpleDateFormat("HH:mm", Locale("az"))
    private val displayDateTime = SimpleDateFormat("d MMM • HH:mm", Locale("az"))

    fun dayKey(timestamp: Long = System.currentTimeMillis()): String =
        dayKeyFormat.format(Date(timestamp))

    fun dayKeyToMillis(dayKey: String): Long? = try {
        dayKeyFormat.parse(dayKey)?.time
    } catch (e: Exception) { null }

    fun startOfDay(timestamp: Long = System.currentTimeMillis()): Long {
        val cal = Calendar.getInstance().apply {
            timeInMillis = timestamp
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return cal.timeInMillis
    }

    fun isSameDay(a: Long, b: Long): Boolean =
        startOfDay(a) == startOfDay(b)

    fun displayDate(timestamp: Long): String = displayFormat.format(Date(timestamp))
    fun displayTime(timestamp: Long): String = displayTime.format(Date(timestamp))
    fun displayDateTime(timestamp: Long): String = displayDateTime.format(Date(timestamp))

    fun daysBetween(startMillis: Long, endMillis: Long): Int {
        val diff = endMillis - startMillis
        return (diff / (24L * 60 * 60 * 1000)).toInt()
    }

    fun hoursUntil(endMillis: Long): Long {
        val diff = endMillis - System.currentTimeMillis()
        return (diff / (60L * 60 * 1000)).coerceAtLeast(0)
    }

    fun nowUtcIso(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
        sdf.timeZone = TimeZone.getTimeZone("UTC")
        return sdf.format(Date())
    }

    fun parseUtcIso(s: String?): Long? {
        if (s.isNullOrBlank()) return null
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            sdf.timeZone = TimeZone.getTimeZone("UTC")
            sdf.parse(s)?.time
        } catch (e: Exception) { null }
    }
}