package com.steptracker.app.ui.broadcast

import android.content.Context
import android.view.LayoutInflater
import android.widget.LinearLayout
import com.bumptech.glide.Glide
import com.steptracker.app.R
import com.steptracker.app.databinding.ViewBroadcastBannerBinding
import com.steptracker.app.model.BroadcastMessage

/**
 * BroadcastBannerView — MainActivity-nin yuxarısında göstərilən broadcast banner-i.
 *
 * Sol yuxarıda X düyməsi var — basıldıqda həmin mesaj üçün "dismissed" işarəsi qoyulur
 * və növbəti proqrama girişə qədər göstərilmir.
 */
class BroadcastBannerView(context: Context) : LinearLayout(context) {

    private val binding: ViewBroadcastBannerBinding =
        ViewBroadcastBannerBinding.inflate(LayoutInflater.from(context), this, true)

    var onDismiss: ((BroadcastMessage) -> Unit)? = null

    private var messages: List<BroadcastMessage> = emptyList()
    private var currentIndex: Int = 0

    fun setBroadcasts(list: List<BroadcastMessage>) {
        messages = list
        currentIndex = 0
        render()
    }

    private fun render() {
        if (messages.isEmpty()) {
            visibility = GONE
            return
        }
        val msg = messages[currentIndex]
        binding.title.text = msg.title
        binding.body.text = msg.body
        if (!msg.imageUrl.isNullOrBlank()) {
            Glide.with(this).load(msg.imageUrl).centerCrop().into(binding.image)
        }
        binding.btnClose.setOnClickListener {
            onDismiss?.invoke(msg)
            // Dismiss olunmuş mesajı siyahıdan çıxar
            messages = messages.filter { it.id != msg.id }
            if (messages.isEmpty()) {
                visibility = GONE
            } else {
                if (currentIndex >= messages.size) currentIndex = 0
                render()
            }
        }
        visibility = VISIBLE
    }
}