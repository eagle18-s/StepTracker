package com.steptracker.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.steptracker.app.R
import com.steptracker.app.StepTrackerApplication
import com.steptracker.app.ui.MainActivity
import com.steptracker.app.util.CalorieCalculator
import com.steptracker.app.util.DateUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first

/**
 * StepWidgetProvider — bugünkü addım sayını göstərən widget.
 *
 * Hər 30 dəqiqədən bir, həmçinin STEP_WIDGET_REFRESH intent aldıqda yenilənir.
 */
class StepWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id -> updateWidget(context, manager, id) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == "com.steptracker.app.STEP_WIDGET_REFRESH") {
            val manager = AppWidgetManager.getInstance(context)
            val component = ComponentName(context, StepWidgetProvider::class.java)
            val ids = manager.getAppWidgetIds(component)
            onUpdate(context, manager, ids)
        }
    }

    private fun updateWidget(context: Context, manager: AppWidgetManager, id: Int) {
        val views = RemoteViews(context.packageName, R.layout.widget_step)
        val app = context.applicationContext as? StepTrackerApplication

        val openIntent = Intent(context, MainActivity::class.java)
        val pi = PendingIntent.getActivity(
            context, 0, openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        views.setOnClickPendingIntent(R.id.widgetRoot, pi)

        if (app == null) {
            manager.updateAppWidget(id, views)
            return
        }

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val today = app.stepRepository.getToday()
                val user = app.authRepository.getCurrentUserCached()
                val steps = today?.steps ?: 0
                val goal = user?.stepGoal ?: 8000
                val percent = CalorieCalculator.goalProgressPercent(steps, goal).coerceAtMost(100)
                val calories = CalorieCalculator.calculate(steps,
                    user?.weightKg ?: com.steptracker.app.util.Constants.DEFAULT_USER_WEIGHT_KG)
                val distanceKm = CalorieCalculator.distanceMeters(steps,
                    user?.heightCm ?: com.steptracker.app.util.Constants.DEFAULT_USER_HEIGHT_CM,
                    user?.isMale ?: true) / 1000.0

                views.setTextViewText(R.id.widgetSteps, steps.toString())
                views.setTextViewText(R.id.widgetGoal, "/ $goal")
                views.setTextViewText(R.id.widgetKcal, context.getString(R.string.kcal_value, calories))
                views.setTextViewText(R.id.widgetKm, context.getString(R.string.km_value, distanceKm))
                views.setTextViewText(R.id.widgetDate, DateUtils.displayDate(System.currentTimeMillis()))
                views.setProgressBar(R.id.widgetProgress, 100, percent, false)
                manager.updateAppWidget(id, views)
            } catch (t: Throwable) {
                views.setTextViewText(R.id.widgetSteps, "—")
                manager.updateAppWidget(id, views)
            }
        }
    }
}