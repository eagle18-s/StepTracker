package com.steptracker.app.ui.duels

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.steptracker.app.databinding.ItemDuelBinding
import com.steptracker.app.model.Duel
import com.steptracker.app.util.DateUtils

class DuelsAdapter(
    private val onClick: (Duel) -> Unit,
    private val onAccept: (Duel) -> Unit,
    private val onDecline: (Duel) -> Unit,
    private val onWithdraw: (Duel) -> Unit
) : ListAdapter<Duel, DuelsAdapter.VH>(Diff) {

    class VH(val binding: ItemDuelBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemDuelBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val duel = getItem(position)
        holder.binding.duelTitle.text = duel.title
        holder.binding.duelType.text = if (duel.type.name == "GROUP")
            "Qrup düellosu" else "1v1 düello"
        holder.binding.timeLeft.text = when (duel.status.name) {
            "ACTIVE" -> "Bitir: " + DateUtils.displayDateTime(duel.endAt)
            "PENDING" -> "Gözləyir..."
            "FINISHED" -> "Bitib"
            "WITHDRAWN" -> "Geri çəkildi"
            "DECLINED" -> "İmtina edildi"
            else -> ""
        }

        holder.binding.root.setOnClickListener { onClick(duel) }
        holder.binding.btnAccept.visibility = if (duel.status.name == "PENDING") View.VISIBLE else View.GONE
        holder.binding.btnDecline.visibility = if (duel.status.name == "PENDING") View.VISIBLE else View.GONE
        holder.binding.btnWithdraw.visibility = if (duel.status.name == "ACTIVE" || duel.status.name == "PENDING") View.VISIBLE else View.GONE

        holder.binding.btnAccept.setOnClickListener { onAccept(duel) }
        holder.binding.btnDecline.setOnClickListener { onDecline(duel) }
        holder.binding.btnWithdraw.setOnClickListener { onWithdraw(duel) }
    }

    object Diff : DiffUtil.ItemCallback<Duel>() {
        override fun areItemsTheSame(a: Duel, b: Duel) = a.id == b.id
        override fun areContentsTheSame(a: Duel, b: Duel) = a == b
    }
}