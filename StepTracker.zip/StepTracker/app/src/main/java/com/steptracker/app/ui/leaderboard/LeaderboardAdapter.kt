package com.steptracker.app.ui.leaderboard

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.steptracker.app.R
import com.steptracker.app.databinding.ItemLeaderboardBinding
import com.steptracker.app.model.LeaderboardEntry

class LeaderboardAdapter : ListAdapter<LeaderboardEntry, LeaderboardAdapter.VH>(Diff) {

    class VH(val b: ItemLeaderboardBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemLeaderboardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val e = getItem(position)
        holder.b.rank.text = "#${e.rank}"
        holder.b.name.text = e.displayName.ifBlank { "İstifadəçi" }
        holder.b.steps.text = "${e.steps} addım"
        if (!e.photoUrl.isNullOrBlank()) {
            Glide.with(holder.b.avatar).load(e.photoUrl).circleCrop().into(holder.b.avatar)
        } else {
            holder.b.avatar.setImageResource(R.drawable.ic_profile_placeholder)
        }
        holder.b.youBadge.visibility = if (e.isSelf) android.view.View.VISIBLE else android.view.View.GONE
        holder.b.friendBadge.visibility = if (e.isFriend) android.view.View.VISIBLE else android.view.View.GONE

        // Top 3 üçün medal rəngi
        holder.b.rankBadge.setBackgroundResource(
            when (e.rank) {
                1 -> R.drawable.rank_badge_gold
                2 -> R.drawable.rank_badge_silver
                3 -> R.drawable.rank_badge_bronze
                else -> R.drawable.rank_badge_default
            }
        )
    }

    object Diff : DiffUtil.ItemCallback<LeaderboardEntry>() {
        override fun areItemsTheSame(a: LeaderboardEntry, b: LeaderboardEntry) = a.uid == b.uid
        override fun areContentsTheSame(a: LeaderboardEntry, b: LeaderboardEntry) = a == b
    }
}