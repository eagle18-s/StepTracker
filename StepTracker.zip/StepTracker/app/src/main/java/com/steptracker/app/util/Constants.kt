package com.steptracker.app.util

object Constants {

    // Folder
    const val APP_FOLDER_NAME = "StepTrackerData"
    const val SUBFOLDER_DAILY = "daily_steps"
    const val SUBFOLDER_SESSIONS = "sessions"
    const val SUBFOLDER_BACKUPS = "backups"
    const val FILE_PREFERENCES = "steptracker_prefs.xml"

    // Prefs keys
    const val PREF_DAILY_BASE_STEPS = "pref_daily_base_steps"
    const val PREF_DAILY_BASE_DATE = "pref_daily_base_date"
    const val PREF_USER_PROFILE = "pref_user_profile"
    const val PREF_BROADCAST_DISMISSED_PREFIX = "pref_broadcast_dismissed_"
    const val PREF_FOLDER_DELETED_FLAG = "pref_folder_deleted_flag"
    const val PREF_PHONE_VERIFIED = "pref_phone_verified"
    const val PREF_GOOGLE_LINKED = "pref_google_linked"

    // Step sensor
    const val STEP_CHANNEL_ID = "step_sensor"
    const val DEFAULT_STEP_GOAL = 8000
    const val NOTIFICATION_STEP_ID = 101

    // Duel
    const val DUEL_DURATION_DAYS = 3
    const val MAX_GROUP_DUEL_SIZE = 10
    const val MIN_GROUP_DUEL_SIZE = 2
    const val MAX_FRIEND_DUEL_DAYS = 3

    // Calories (defaults)
    const val DEFAULT_USER_WEIGHT_KG = 70.0
    const val DEFAULT_USER_HEIGHT_CM = 170.0
    const val DEFAULT_USER_AGE = 30
    const val DEFAULT_USER_GENDER_MALE = true

    // Calories formula coefficients
    // kcal per step ≈ (body weight kg * 0.0005) — simplified Harris-Benedict approximation
    const val KCAL_PER_STEP_PER_KG = 0.0005

    // Friend / leaderboard
    const val LEADERBOARD_TOP_N = 100

    // Broadcast companion package
    const val BROADCAST_PACKAGE = "com.broadcast.app"
    const val BROADCAST_SHARED_FILE = "broadcast_messages.json"

    // RC codes
    const val RC_SIGN_IN = 9001
    const val RC_PHONE_VERIFY = 9002
    const val RC_LOCATION_PERM = 9003
    const val RC_ACTIVITY_RECOGNITION = 9004
    const val RC_NOTIFICATIONS = 9005
}