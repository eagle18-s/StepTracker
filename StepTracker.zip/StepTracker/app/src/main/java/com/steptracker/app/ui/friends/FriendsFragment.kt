package com.steptracker.app.ui.friends

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.steptracker.app.R
import com.steptracker.app.StepTrackerApplication
import com.steptracker.app.databinding.FragmentFriendsBinding
import com.steptracker.app.model.Friend
import com.steptracker.app.ui.chat.ChatActivity
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * Dostlar siyahısı + dostluq sorğuları + axtarış.
 */
class FriendsFragment : Fragment() {

    private var _binding: FragmentFriendsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: FriendsViewModel by viewModels()
    private lateinit var adapter: FriendsAdapter
    private lateinit var requestsAdapter: FriendRequestsAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View {
        _binding = FragmentFriendsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val app = requireActivity().application as StepTrackerApplication

        adapter = FriendsAdapter(
            onClick = { friend ->
                val intent = Intent(requireContext(), ChatActivity::class.java)
                    .putExtra("friendUid", friend.uid)
                    .putExtra("friendName", friend.displayName)
                startActivity(intent)
            },
            onRemove = { friend ->
                MaterialAlertDialogBuilder(requireContext())
                    .setTitle(R.string.remove_friend_title)
                    .setMessage(getString(R.string.remove_friend_msg, friend.displayName))
                    .setPositiveButton(R.string.remove) { _, _ ->
                        viewModel.removeFriend(app, friend.uid)
                    }
                    .setNegativeButton(R.string.cancel, null)
                    .show()
            }
        )
        binding.recyclerFriends.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerFriends.adapter = adapter

        requestsAdapter = FriendRequestsAdapter(
            onAccept = { req -> viewModel.acceptRequest(app, req) },
            onDecline = { req -> viewModel.declineRequest(app, req) }
        )
        binding.recyclerRequests.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerRequests.adapter = requestsAdapter

        binding.btnSearch.setOnClickListener { showSearchDialog() }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.friends.collectLatest { list ->
                adapter.submitList(list)
                binding.emptyView.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.requests.collectLatest { list ->
                requestsAdapter.submitList(list)
                binding.requestsHeader.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
            }
        }

        viewModel.load(app)
    }

    private fun showSearchDialog() {
        val input = TextInputEditText(requireContext())
        input.hint = getString(R.string.search_email_hint)
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.add_friend)
            .setView(input)
            .setPositiveButton(R.string.send_request) { _, _ ->
                val email = input.text.toString().trim()
                if (email.isNotEmpty()) {
                    viewModel.sendRequestByEmail(requireContext().applicationContext as StepTrackerApplication, email)
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}