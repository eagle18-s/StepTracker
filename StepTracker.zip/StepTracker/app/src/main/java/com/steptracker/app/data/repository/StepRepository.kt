package com.steptracker.app.data.repository

import android.content.Context
import com.steptracker.app.data.local.StepDao
import com.steptracker.app.data.local.StepEntity
import com.steptracker.app.util.DateUtils
import kotlinx.coroutines.flow.Flow

/**
 * StepRepository — yalnız lokal addım məlumatları.
 * Heç bir serverə göndərmir.
 */
class StepRepository(
    private val context: Context,
    private val dao: StepDao
) {

    suspend fun saveToday(steps: Int, calories: Double, distanceMeters: Double,
                          activeMinutes: Int, elevationGainMeters: Double = 0.0,
                          source: String = "TYPE_STEP_COUNTER") {
        val entity = StepEntity(
            dayKey = DateUtils.dayKey(),
            steps = steps,
            calories = calories,
            distanceMeters = distanceMeters,
            activeMinutes = activeMinutes,
            elevationGainMeters = elevationGainMeters,
            sensorSource = source,
            updatedAt = System.currentTimeMillis()
        )
        dao.upsertDay(entity)
    }

    suspend fun getToday(): StepEntity? = dao.getDay(DateUtils.dayKey())

    fun observeToday(): Flow<StepEntity?> = dao.observeDay(DateUtils.dayKey())

    fun observeRecentDays(limit: Int = 7): Flow<List<StepEntity>> = dao.observeRecent(limit)

    suspend fun getRange(fromDay: String, toDay: String): List<StepEntity> =
        dao.getRange(fromDay, toDay)

    suspend fun totalStepsForLast(days: Int): Int {
        val (from, _) = computeRange(days)
        return dao.getRange(from, DateUtils.dayKey()).sumOf { it.steps }
    }

    private fun computeRange(days: Int): Pair<String, String> {
        val cal = java.util.Calendar.getInstance()
        cal.add(java.util.Calendar.DAY_OF_YEAR, -(days - 1))
        val fromDay = DateUtils.dayKey(cal.timeInMillis)
        return fromDay to DateUtils.dayKey()
    }
}