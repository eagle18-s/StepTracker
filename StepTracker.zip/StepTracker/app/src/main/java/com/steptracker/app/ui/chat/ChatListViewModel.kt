package com.steptracker.app.ui.chat

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.steptracker.app.StepTrackerApplication
import com.steptracker.app.model.Conversation
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class ChatListViewModel(app: Application) : AndroidViewModel(app) {

    private val _conversations = MutableStateFlow<List<Conversation>>(emptyList())
    val conversations: StateFlow<List<Conversation>> = _conversations.asStateFlow()

    fun load(app: StepTrackerApplication) {
        val uid = app.authRepository.currentUid() ?: return
        viewModelScope.launch {
            app.messageRepository.observeConversations(uid).collectLatest { _conversations.value = it }
        }
    }
}