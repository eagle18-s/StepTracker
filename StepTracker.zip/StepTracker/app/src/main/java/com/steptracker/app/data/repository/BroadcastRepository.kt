package com.steptracker.app.data.repository

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.steptracker.app.model.BroadcastMessage
import com.steptracker.app.util.Constants
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.File

/**
 * BroadcastRepository — StepTrackerBroadcast companion app tərəfindən yazılmış
 * broadcast_messages.json faylını oxuyur.
 *
 * Shared storage pattern: hər iki app eyni external folder-ə baxır.
 *
 * Layout: <external>/StepTrackerBroadcast/broadcast_messages.json
 * [
 *   { id, title, body, imageUrl, actionUrl, priority, sentAt, expiresAt },
 *   ...
 * ]
 */
class BroadcastRepository(private val context: Context) {

    private val gson = Gson()

    /**
     * Broadcast faylının yeri — companion app ilə eyni qovluq.
     */
    val broadcastFile: File
        get() {
            val externalRoot = android.os.Environment.getExternalStorageDirectory()
            return File(File(externalRoot, "StepTrackerBroadcast"), "broadcast_messages.json")
        }

    /**
     * Bütün aktiv (vaxtı keçməmiş) broadcast-ları oxu.
     */
    suspend fun loadActiveBroadcasts(): List<BroadcastMessage> = withContext(Dispatchers.IO) {
        try {
            val file = broadcastFile
            if (!file.exists()) return@withContext emptyList()
            val json = file.readText(Charsets.UTF_8)
            if (json.isBlank()) return@withContext emptyList()
            val type = object : TypeToken<List<BroadcastMessage>>() {}.type
            val list: List<BroadcastMessage> = gson.fromJson(json, type) ?: emptyList()
            val now = System.currentTimeMillis()
            list.filter { msg ->
                val expiresAt = msg.expiresAt
                expiresAt == null || expiresAt > now
            }.sortedByDescending { it.priority }
        } catch (t: Throwable) {
            Timber.w(t, "loadActiveBroadcasts failed")
            emptyList()
        }
    }

    /**
     * Lokal cache faylı — broadcast-ların cache-i (şəbəkə olmadıqda üçün).
     */
    private val cacheFile: File
        get() = File(context.filesDir, "broadcast_cache.json")

    suspend fun loadCachedBroadcasts(): List<BroadcastMessage> = withContext(Dispatchers.IO) {
        try {
            if (!cacheFile.exists()) return@withContext emptyList()
            val json = cacheFile.readText()
            if (json.isBlank()) return@withContext emptyList()
            val type = object : TypeToken<List<BroadcastMessage>>() {}.type
            gson.fromJson(json, type) ?: emptyList()
        } catch (t: Throwable) {
            Timber.w(t, "loadCachedBroadcasts failed")
            emptyList()
        }
    }

    suspend fun cacheBroadcasts(list: List<BroadcastMessage>) = withContext(Dispatchers.IO) {
        try {
            cacheFile.parentFile?.mkdirs()
            cacheFile.writeText(gson.toJson(list))
        } catch (t: Throwable) {
            Timber.w(t, "cacheBroadcasts failed")
        }
    }
}