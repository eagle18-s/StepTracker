package com.steptracker.app.ui.friends

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.steptracker.app.databinding.ItemFriendBinding
import com.steptracker.app.model.Friend

class FriendsAdapter(
    private val onClick: (Friend) -> Unit,
    private val onRemove: (Friend) -> Unit
) : ListAdapter<Friend, FriendsAdapter.VH>(Diff) {

    class VH(val binding: ItemFriendBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemFriendBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val f = getItem(position)
        holder.binding.friendName.text = f.displayName
        holder.binding.friendEmail.text = f.email
        if (!f.photoUrl.isNullOrBlank()) {
            Glide.with(holder.binding.avatar).load(f.photoUrl).circleCrop().into(holder.binding.avatar)
        } else {
            holder.binding.avatar.setImageResource(com.steptracker.app.R.drawable.ic_profile_placeholder)
        }
        holder.binding.root.setOnClickListener { onClick(f) }
        holder.binding.btnRemove.setOnClickListener { onRemove(f) }
    }

    object Diff : DiffUtil.ItemCallback<Friend>() {
        override fun areItemsTheSame(a: Friend, b: Friend) = a.uid == b.uid
        override fun areContentsTheSame(a: Friend, b: Friend) = a == b
    }
}