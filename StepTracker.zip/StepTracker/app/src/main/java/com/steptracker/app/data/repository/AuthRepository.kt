package com.steptracker.app.data.repository

import android.app.Activity
import android.content.Context
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import com.google.firebase.FirebaseException
import com.google.firebase.auth.*
import com.google.firebase.firestore.FirebaseFirestore
import com.steptracker.app.model.User
import kotlinx.coroutines.tasks.await
import timber.log.Timber
import java.util.concurrent.TimeUnit

/**
 * Authentication repository — Firebase Auth + Google Sign-In + Phone verification.
 *
 * İstifadəçi məlumatları həm Firebase Auth-da, həm də Firestore "users" collection-unda saxlanılır.
 * Addım məlumatları isə LOCAL olaraq qalır (serverə göndərilmir).
 */
class AuthRepository {

    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()

    fun isSignedIn(): Boolean = auth.currentUser != null

    fun currentUid(): String? = auth.currentUser?.uid

    fun signOut() {
        auth.signOut()
    }

    /**
     * Google Sign-In client yaradır.
     * default_web_client_id — Firebase konsolundan götürülür (build.gradle-ə əlavə olunur).
     */
    fun googleSignInClient(context: Context): GoogleSignInClient {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(context.getString(com.steptracker.app.R.string.default_web_client_id))
            .requestEmail()
            .requestProfile()
            .build()
        return GoogleSignIn.getClient(context, gso)
    }

    /**
     * Google Sign-In intent-i başladır.
     */
    fun getSignInIntent(context: Context) = googleSignInClient(context).signInIntent

    /**
     * Google Sign-In nəticəsini emal edir.
     */
    suspend fun handleGoogleSignInResult(task: Task<GoogleSignInAccount>): User {
        val account = try { task.getResult(ApiException::class.java) }
        catch (e: ApiException) {
            Timber.w(e, "Google Sign-In failed")
            throw e
        }
        return firebaseAuthWithGoogle(account)
    }

    private suspend fun firebaseAuthWithGoogle(account: GoogleSignInAccount): User {
        val credential = GoogleAuthProvider.getCredential(account.idToken, null)
        val authResult = auth.signInWithCredential(credential).await()
        val firebaseUser = authResult.user
            ?: throw IllegalStateException("Firebase user null after sign-in")

        // Firestore profile yarat / yenilə
        val user = User(
            uid = firebaseUser.uid,
            email = firebaseUser.email ?: account.email ?: "",
            displayName = firebaseUser.displayName ?: account.displayName ?: "",
            photoUrl = firebaseUser.photoUrl?.toString() ?: account.photoUrl?.toString(),
            phoneNumber = firebaseUser.phoneNumber,
            phoneVerified = firebaseUser.phoneNumber != null
        )
        upsertUserProfile(user)
        return user
    }

    /**
     * Telefon nömrəsinə doğrulama kodu göndərir.
     */
    fun startPhoneVerification(
        activity: Activity,
        phoneNumber: String,
        callbacks: PhoneAuthProvider.OnVerificationStateChangedCallbacks
    ): PhoneAuthProvider.ForceResendingToken? {
        val options = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(phoneNumber)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(activity)
            .setCallbacks(callbacks)
            .build()
        PhoneAuthProvider.verifyPhoneNumber(options)
        return null
    }

    /**
     * Telefon doğrulama kodunu təsdiq edir, sonra phone credential ilə Firebase-e daxil olur.
     */
    suspend fun verifyPhoneCode(verificationId: String, code: String): User? {
        val credential = PhoneAuthProvider.getCredential(verificationId, code)
        val result = auth.signInWithCredential(credential).await()
        val firebaseUser = result.user ?: return null
        val existing = getCurrentUserCached() ?: User(
            uid = firebaseUser.uid,
            email = firebaseUser.email ?: "",
            displayName = firebaseUser.displayName ?: firebaseUser.phoneNumber ?: "İstifadəçi",
            phoneNumber = firebaseUser.phoneNumber,
            phoneVerified = true
        ).also { upsertUserProfile(it.copy(phoneVerified = true)) }

        return existing.copy(
            phoneNumber = firebaseUser.phoneNumber,
            phoneVerified = true
        )
    }

    suspend fun resendPhoneCode(
        activity: Activity,
        phoneNumber: String,
        token: PhoneAuthProvider.ForceResendingToken,
        callbacks: PhoneAuthProvider.OnVerificationStateChangedCallbacks
    ) {
        val options = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(phoneNumber)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(activity)
            .setCallbacks(callbacks)
            .setForceResendingToken(token)
            .build()
        PhoneAuthProvider.verifyPhoneNumber(options)
    }

    /**
     * Cari istifadəçini Firestore-dan oxuyur (cache-lənmiş).
     */
    suspend fun getCurrentUserCached(): User? {
        val uid = auth.currentUser?.uid ?: return null
        return try {
            val doc = firestore.collection("users").document(uid).get().await()
            if (!doc.exists()) {
                val fb = auth.currentUser!!
                User(
                    uid = fb.uid,
                    email = fb.email ?: "",
                    displayName = fb.displayName ?: fb.phoneNumber ?: "İstifadəçi",
                    photoUrl = fb.photoUrl?.toString(),
                    phoneNumber = fb.phoneNumber,
                    phoneVerified = fb.phoneNumber != null
                ).also { upsertUserProfile(it) }
            } else {
                doc.toObject(User::class.java)
            }
        } catch (t: Throwable) {
            Timber.w(t, "getCurrentUserCached failed")
            null
        }
    }

    /**
     * Profili Firestore-a yazır.
     */
    suspend fun upsertUserProfile(user: User) {
        try {
            firestore.collection("users").document(user.uid).set(user).await()
        } catch (t: Throwable) {
            Timber.w(t, "upsertUserProfile failed")
        }
    }

    /**
     * Profil xüsusiləşdirmə — telefon, çəki, hündürlük, yaş, cins, addım məqsədi.
     */
    suspend fun updateUserProfile(
        displayName: String? = null,
        heightCm: Double? = null,
        weightKg: Double? = null,
        age: Int? = null,
        isMale: Boolean? = null,
        stepGoal: Int? = null,
        photoUrl: String? = null
    ): User? {
        val uid = auth.currentUser?.uid ?: return null
        val updates = mutableMapOf<String, Any>()
        displayName?.let { updates["displayName"] = it }
        heightCm?.let { updates["heightCm"] = it }
        weightKg?.let { updates["weightKg"] = it }
        age?.let { updates["age"] = it }
        isMale?.let { updates["isMale"] = it }
        stepGoal?.let { updates["stepGoal"] = it }
        photoUrl?.let { updates["photoUrl"] = it }
        updates["lastActiveAt"] = System.currentTimeMillis()

        try {
            firestore.collection("users").document(uid).update(updates).await()
            return getCurrentUserCached()
        } catch (t: Throwable) {
            Timber.w(t, "updateUserProfile failed")
            return getCurrentUserCached()
        }
    }

    /**
     * FCM token-i Firestore-da saxlayır (push notifications üçün).
     */
    suspend fun saveFcmToken(token: String) {
        val uid = auth.currentUser?.uid ?: return
        try {
            firestore.collection("users").document(uid).update("fcmToken", token).await()
        } catch (t: Throwable) {
            Timber.w(t, "saveFcmToken failed")
        }
    }
}