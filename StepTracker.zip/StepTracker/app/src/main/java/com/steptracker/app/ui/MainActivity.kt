package com.steptracker.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.steptracker.app.R
import com.steptracker.app.StepTrackerApplication
import com.steptracker.app.databinding.ActivityMainBinding
import com.steptracker.app.ui.broadcast.BroadcastBannerView
import com.steptracker.app.ui.chat.ChatListFragment
import com.steptracker.app.ui.complaint.ComplaintActivity
import com.steptracker.app.ui.duels.DuelsFragment
import com.steptracker.app.ui.friends.FriendsFragment
import com.steptracker.app.ui.home.HomeFragment
import com.steptracker.app.ui.leaderboard.LeaderboardFragment
import kotlinx.coroutines.launch
import timber.log.Timber

/**
 * MainActivity — proqramın əsas ekranı.
 *
 * Layout:
 *  ┌──────────────────────────────────┐
 *  │ BroadcastBanner (optional)       │
 *  ├──────────────────────────────────┤
 *  │ Toolbar                          │
 *  ├──────────────────────────────────┤
 *  │                                  │
 *  │      Fragment container          │
 *  │                                  │
 *  ├──────────────────────────────────┤
 *  │ BottomNav (Home/Friends/Duels/   │
 *  │            Leaderboard/Chat)     │
 *  └──────────────────────────────────┘
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupBottomNav()
        setupToolbar()
        loadBroadcasts()

        if (savedInstanceState == null) {
            switchTo(R.id.nav_home)
        }
    }

    private fun setupBottomNav() {
        binding.bottomNav.setOnItemSelectedListener { item ->
            switchTo(item.itemId)
            true
        }
    }

    private fun setupToolbar() {
        binding.toolbar.title = getString(R.string.app_name)
        binding.toolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.menu_complaint -> {
                    startActivity(Intent(this, ComplaintActivity::class.java))
                    true
                }
                R.id.menu_profile -> {
                    startActivity(Intent(this,
                        com.steptracker.app.ui.auth.ProfileSetupActivity::class.java))
                    true
                }
                R.id.menu_logout -> {
                    MaterialAlertDialogBuilder(this)
                        .setTitle(R.string.logout_title)
                        .setMessage(R.string.logout_msg)
                        .setPositiveButton(R.string.logout_yes) { _, _ ->
                            (application as StepTrackerApplication).authRepository.signOut()
                            startActivity(Intent(this,
                                com.steptracker.app.ui.auth.LoginActivity::class.java))
                            finish()
                        }
                        .setNegativeButton(R.string.cancel, null)
                        .show()
                    true
                }
                else -> false
            }
        }
    }

    private fun switchTo(itemId: Int) {
        val fragment = when (itemId) {
            R.id.nav_home -> HomeFragment()
            R.id.nav_friends -> FriendsFragment()
            R.id.nav_duels -> DuelsFragment()
            R.id.nav_leaderboard -> LeaderboardFragment()
            R.id.nav_chat -> ChatListFragment()
            else -> HomeFragment()
        }
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()

        binding.toolbar.title = when (itemId) {
            R.id.nav_home -> getString(R.string.app_name)
            R.id.nav_friends -> getString(R.string.tab_friends)
            R.id.nav_duels -> getString(R.string.tab_duels)
            R.id.nav_leaderboard -> getString(R.string.tab_leaderboard)
            R.id.nav_chat -> getString(R.string.tab_chat)
            else -> getString(R.string.app_name)
        }
    }

    /**
     * Broadcast mesajlarını yükləyib yuxarıda göstərir.
     */
    private fun loadBroadcasts() {
        val app = application as StepTrackerApplication
        lifecycleScope.launch {
            val broadcasts = app.broadcastRepository.loadActiveBroadcasts()
            val cached = app.broadcastRepository.loadCachedBroadcasts()
            val all = (broadcasts.ifEmpty { cached })
                .distinctBy { it.id }
                .filter { msg ->
                    val dismissedKey = "pref_broadcast_dismissed_${msg.id}"
                    val prefs = getSharedPreferences(
                        com.steptracker.app.util.Constants.FILE_PREFERENCES, MODE_PRIVATE)
                    !prefs.getBoolean(dismissedKey, false)
                }

            if (all.isNotEmpty()) {
                binding.bannerContainer.visibility = View.VISIBLE
                binding.bannerContainer.removeAllViews()
                val banner = BroadcastBannerView(this@MainActivity).apply {
                    setBroadcasts(all)
                    onDismiss = { msg ->
                        val prefs = getSharedPreferences(
                            com.steptracker.app.util.Constants.FILE_PREFERENCES, MODE_PRIVATE)
                        prefs.edit()
                            .putBoolean("pref_broadcast_dismissed_${msg.id}", true)
                            .apply()
                    }
                }
                binding.bannerContainer.addView(banner)
            } else {
                binding.bannerContainer.visibility = View.GONE
            }
        }
    }
}