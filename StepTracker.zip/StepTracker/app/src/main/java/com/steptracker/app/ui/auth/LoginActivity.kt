package com.steptracker.app.ui.auth

import android.content.Intent
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.common.api.ApiException
import com.steptracker.app.R
import com.steptracker.app.StepTrackerApplication
import com.steptracker.app.databinding.ActivityLoginBinding
import kotlinx.coroutines.launch
import timber.log.Timber

/**
 * LoginActivity — Google Sign-In.
 *
 * Google Sign-In mütləqdir. Telefon nömrəsi doğrulaması sonrakı mərhələdədir
 * (profil qurma ekranında).
 */
class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    private val googleSignInLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        try {
            lifecycleScope.launch {
                val user = (application as StepTrackerApplication)
                    .authRepository.handleGoogleSignInResult(task)
                onLoginSuccess(user.phoneVerified, user.phoneNumber)
            }
        } catch (e: ApiException) {
            Timber.w(e, "Google Sign-In failed")
            binding.errorText.text = getString(R.string.login_error_generic, e.statusCode)
            binding.errorText.visibility = android.view.View.VISIBLE
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnGoogleSignIn.setOnClickListener {
            val intent = (application as StepTrackerApplication)
                .authRepository.getSignInIntent(this)
            googleSignInLauncher.launch(intent)
        }

        binding.termsText.text = getString(R.string.login_terms)
    }

    private fun onLoginSuccess(phoneVerified: Boolean, phoneNumber: String?) {
        if (!phoneVerified || phoneNumber.isNullOrBlank()) {
            startActivity(Intent(this, PhoneVerificationActivity::class.java))
        } else {
            startActivity(Intent(this, ProfileSetupActivity::class.java))
        }
        finish()
    }
}