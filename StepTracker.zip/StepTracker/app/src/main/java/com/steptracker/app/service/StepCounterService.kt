package com.steptracker.app.service

import android.Manifest
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.fitness.Fitness
import com.google.android.gms.fitness.FitnessOptions
import com.google.android.gms.fitness.data.DataType
import com.google.android.gms.fitness.data.Field
import com.steptracker.app.R
import com.steptracker.app.StepTrackerApplication
import com.steptracker.app.data.local.StepSessionEntity
import com.steptracker.app.ui.MainActivity
import com.steptracker.app.util.CalorieCalculator
import com.steptracker.app.util.Constants
import com.steptracker.app.util.DateUtils
import kotlinx.coroutines.*
import timber.log.Timber

/**
 * StepCounterService — foreground xidməti.
 *
 * İki mənbədən addım oxuyur:
 *  1) Hardware step counter sensor (TYPE_STEP_COUNTER) — telefonun öz sensoru
 *  2) Google Fit History API — daha dəqiq, qalıq-state (kill olunsa belə qorunur)
 *
 * GPS aktiv olduqda yüksəklik dəyişikliyini izləyərək kalori hesablamasını düzəldir.
 *
 * Day rollover: gün dəyişəndə sensor baseline-ı sıfırlanır ki, hər gün 0-dan başlasın.
 */
class StepCounterService : Service(), SensorEventListener, LocationListener {

    private lateinit var sensorManager: SensorManager
    private var stepCounterSensor: Sensor? = null
    private var stepDetectorSensor: Sensor? = null
    private lateinit var locationManager: LocationManager
    private lateinit var powerManager: PowerManager
    private var wakeLock: PowerManager.WakeLock? = null

    private val app get() = application as StepTrackerApplication
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // Sensor state
    private var sensorBaseline: Float = -1f
    private var lastSavedSteps: Int = 0
    private var lastSavedDayKey: String = ""
    private var currentSessionId: Long = -1L
    private var sessionStartSteps: Int = 0

    // GPS / elevation
    private var lastElevation: Double? = null
    private var elevationGainMeters: Double = 0.0
    private var gpsEnabled: Boolean = false

    // Google Fit
    private var googleFitAvailable: Boolean = false

    override fun onCreate() {
        super.onCreate()
        Timber.d("StepCounterService onCreate")
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager

        stepCounterSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        stepDetectorSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR)

        if (stepCounterSensor == null && stepDetectorSensor == null) {
            Timber.w("No step sensors available on this device")
        }

        // Google Fit mövcudluğunu yoxla
        try {
            val fitnessOptions = FitnessOptions.builder()
                .addDataType(DataType.TYPE_STEP_COUNT_DELTA, FitnessOptions.ACCESS_READ)
                .addDataType(DataType.TYPE_CALORIES_EXPENDED, FitnessOptions.ACCESS_READ)
                .addDataType(DataType.TYPE_DISTANCE_DELTA, FitnessOptions.ACCESS_READ)
                .build()
            val account = GoogleSignIn.getLastSignedInAccount(this)
            googleFitAvailable = account != null &&
                GoogleSignIn.hasPermissions(account, fitnessOptions)
        } catch (t: Throwable) {
            Timber.w(t, "GoogleFit init failed")
            googleFitAvailable = false
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startInForeground()
        acquireWakeLock()
        registerSensors()
        registerGps()
        startNewSession()
        return START_STICKY
    }

    private fun startInForeground() {
        val openAppIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, Constants.STEP_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_step_notification)
            .setContentTitle(getString(R.string.step_service_title))
            .setContentText(getString(R.string.step_service_text, lastSavedSteps))
            .setContentIntent(openAppIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setShowWhen(false)
            .setOnlyAlertOnce(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                Constants.NOTIFICATION_STEP_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_HEALTH or
                    if (gpsEnabled) ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0
            )
        } else {
            startForeground(Constants.NOTIFICATION_STEP_ID, notification)
        }
    }

    private fun acquireWakeLock() {
        try {
            wakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "StepTracker::StepCounterWakeLock"
            ).apply {
                setReferenceCounted(false)
                acquire(60 * 60 * 1000L) // 1 saat
            }
        } catch (t: Throwable) {
            Timber.w(t, "WakeLock acquire failed")
        }
    }

    private fun registerSensors() {
        stepCounterSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
        stepDetectorSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }

    private fun registerGps() {
        val fineLoc = ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        if (!fineLoc) {
            Timber.d("GPS permission not granted, skipping location tracking")
            return
        }
        gpsEnabled = true
        try {
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    10_000L,        // 10 saniyə
                    5f,             // 5 metr
                    this
                )
            }
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(
                    LocationManager.NETWORK_PROVIDER,
                    30_000L,
                    10f,
                    this
                )
            }
        } catch (se: SecurityException) {
            Timber.w(se, "GPS permission revoked at runtime")
        }
    }

    private fun startNewSession() {
        scope.launch {
            val now = System.currentTimeMillis()
            val entity = StepSessionEntity(
                sessionStart = now,
                sessionEnd = null,
                startSteps = 0,
                endSteps = null,
                stepsDelta = 0,
                source = if (googleFitAvailable) "google_fit+hardware_sensor" else "hardware_sensor"
            )
            currentSessionId = app.database.stepSessionDao().insert(entity)
            sessionStartSteps = lastSavedSteps
        }
    }

    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_STEP_COUNTER -> {
                val raw = event.values.firstOrNull()?.toInt() ?: return
                if (sensorBaseline < 0f) {
                    sensorBaseline = raw.toFloat()
                    lastSavedSteps = 0
                }
                val currentSteps = (raw - sensorBaseline).coerceAtLeast(0)
                handleStepEvent(currentSteps, source = "TYPE_STEP_COUNTER")
            }
            Sensor.TYPE_STEP_DETECTOR -> {
                // Hər event = 1 addım (bütün gün üçün baseline saxlamırıq, delta əlavə edirik)
                handleStepEvent(lastSavedSteps + 1, source = "TYPE_STEP_DETECTOR")
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private fun handleStepEvent(currentSteps: Int, source: String) {
        // Day rollover: gün dəyişibsə sensor baseline-ı sıfırla
        val today = DateUtils.dayKey()
        if (lastSavedDayKey.isNotEmpty() && today != lastSavedDayKey) {
            sensorBaseline = -1f
            lastSavedSteps = 0
        }
        lastSavedDayKey = today
        lastSavedSteps = currentSteps

        scope.launch {
            persistSteps(currentSteps, source)
        }
    }

    private suspend fun persistSteps(steps: Int, source: String) {
        val today = DateUtils.dayKey()
        val user = app.authRepository.getCurrentUserCached() ?: return
        val existing = app.database.stepDao().getDay(today)

        val calories = CalorieCalculator.calculateWithElevation(
            steps = steps,
            weightKg = user.weightKg,
            elevationGainMeters = elevationGainMeters
        )
        val distance = CalorieCalculator.distanceMeters(steps, user.heightCm, user.isMale)
        val activeMin = CalorieCalculator.activeMinutes(steps)

        val entity = com.steptracker.app.data.local.StepEntity(
            dayKey = today,
            steps = steps,
            calories = calories,
            distanceMeters = distance,
            activeMinutes = activeMin,
            elevationGainMeters = elevationGainMeters,
            sensorSource = source,
            updatedAt = System.currentTimeMillis()
        )

        app.database.stepDao().upsertDay(entity)
        refreshNotification(steps)

        // Hər 5 dəqiqədən bir duel iştirakçılarının addım snapshot-ını Firestore-a yaz
        if (System.currentTimeMillis() % (5 * 60 * 1000L) < 30_000L) {
            try {
                app.duelRepository.updateMyStepSnapshots(uid = user.uid, steps = steps.toLong())
            } catch (t: Throwable) {
                Timber.w(t, "Failed to push duel snapshot")
            }
        }

        // Widget yeniləmə broadcast göndər
        sendBroadcast(Intent("com.steptracker.app.STEP_WIDGET_REFRESH"))
    }

    private fun refreshNotification(steps: Int) {
        val openAppIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification = NotificationCompat.Builder(this, Constants.STEP_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_step_notification)
            .setContentTitle(getString(R.string.step_service_title))
            .setContentText(getString(R.string.step_service_text, steps))
            .setContentIntent(openAppIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setShowWhen(false)
            .setOnlyAlertOnce(true)
            .build()
        val nm = androidx.core.app.NotificationManagerCompat.from(this)
        if (nm.areNotificationsEnabled()) {
            try {
                nm.notify(Constants.NOTIFICATION_STEP_ID, notification)
            } catch (se: SecurityException) {
                Timber.w(se, "Notification permission missing")
            }
        }
    }

    // GPS callback
    override fun onLocationChanged(location: Location) {
        val alt = location.altitude
        val prev = lastElevation
        if (prev != null && alt > prev) {
            elevationGainMeters += (alt - prev)
        }
        lastElevation = alt
    }

    @Deprecated("API < 29")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) = Unit

    override fun onProviderEnabled(provider: String) = Unit
    override fun onProviderDisabled(provider: String) = Unit

    override fun onDestroy() {
        super.onDestroy()
        Timber.d("StepCounterService onDestroy")
        sensorManager.unregisterListener(this)
        try {
            locationManager.removeUpdates(this)
        } catch (se: SecurityException) {
            Timber.w(se)
        }
        try {
            wakeLock?.release()
        } catch (t: Throwable) { /* ignore */ }

        // Session bağla
        scope.launch {
            if (currentSessionId > 0) {
                app.database.stepSessionDao().close(
                    id = currentSessionId,
                    end = System.currentTimeMillis(),
                    endSteps = lastSavedSteps,
                    delta = (lastSavedSteps - sessionStartSteps).coerceAtLeast(0)
                )
            }
            scope.cancel()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        fun start(context: Context) {
            val intent = Intent(context, StepCounterService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, StepCounterService::class.java))
        }
    }
}