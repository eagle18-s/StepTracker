package com.steptracker.app.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.steptracker.app.R
import com.steptracker.app.StepTrackerApplication
import com.steptracker.app.service.StepCounterService
import com.steptracker.app.ui.auth.FolderRestoreActivity
import com.steptracker.app.ui.auth.LoginActivity
import kotlinx.coroutines.launch
import timber.log.Timber

/**
 * SplashActivity — proqram açılanda ilk activity.
 *
 * Yoxlama siyahısı:
 *  1) Folder mövcuddur? — yoxdursa FolderRestoreActivity
 *  2) İstifadəçi daxil olub? — yoxdursa LoginActivity
 *  3) Profil tamdır? — yoxdursa ProfileSetupActivity
 *  4) Əsas MainActivity
 *
 * Eyni zamanda lazım olan permissions-ları istəyir.
 */
class SplashActivity : AppCompatActivity() {

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        Timber.d("Permission results: $results")
        decideNextStep()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        // Qısa splash delay
        Handler(Looper.getMainLooper()).postDelayed({
            requestNeededPermissions()
        }, 700)
    }

    private fun requestNeededPermissions() {
        val perms = mutableListOf<String>()

        // Activity Recognition (Android 10+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACTIVITY_RECOGNITION)
                != PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.ACTIVITY_RECOGNITION)
        }

        // Location (for GPS + calories adjustment)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }

        // Notifications (Android 13+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        if (perms.isEmpty()) {
            decideNextStep()
        } else {
            permissionLauncher.launch(perms.toTypedArray())
        }
    }

    private fun decideNextStep() {
        val app = application as StepTrackerApplication

        // 1) Folder yoxlaması
        if (app.folderManager.isFolderMissing()) {
            startActivity(Intent(this, FolderRestoreActivity::class.java))
            finish()
            return
        }

        // 2) Auth yoxlaması
        if (!app.authRepository.isSignedIn()) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        // 3) Profil tamdır? (boy/çəki/yaş məlumatı vacibdir)
        lifecycleScope.launch {
            val user = app.authRepository.getCurrentUserCached()
            if (user == null || user.weightKg <= 0 || user.heightCm <= 0 || user.age <= 0) {
                startActivity(Intent(this@SplashActivity,
                    com.steptracker.app.ui.auth.ProfileSetupActivity::class.java))
            } else {
                // Step counter service-i başlat
                StepCounterService.start(this@SplashActivity)
                startActivity(Intent(this@SplashActivity, MainActivity::class.java))
            }
            finish()
        }
    }
}