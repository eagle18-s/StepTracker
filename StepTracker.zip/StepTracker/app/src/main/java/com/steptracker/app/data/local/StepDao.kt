package com.steptracker.app.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface StepDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDay(entity: StepEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(entities: List<StepEntity>)

    @Query("SELECT * FROM daily_steps WHERE dayKey = :dayKey LIMIT 1")
    suspend fun getDay(dayKey: String): StepEntity?

    @Query("SELECT * FROM daily_steps WHERE dayKey = :dayKey LIMIT 1")
    fun observeDay(dayKey: String): Flow<StepEntity?>

    @Query("SELECT * FROM daily_steps WHERE dayKey BETWEEN :from AND :to ORDER BY dayKey ASC")
    suspend fun getRange(from: String, to: String): List<StepEntity>

    @Query("SELECT * FROM daily_steps ORDER BY dayKey DESC LIMIT :limit")
    fun observeRecent(limit: Int = 30): Flow<List<StepEntity>>

    @Query("SELECT SUM(steps) FROM daily_steps WHERE dayKey = :dayKey")
    suspend fun sumStepsForDay(dayKey: String): Int?

    @Query("DELETE FROM daily_steps")
    suspend fun clearAll()
}

@Dao
interface StepSessionDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: StepSessionEntity): Long

    @Query("UPDATE step_sessions SET sessionEnd = :end, endSteps = :endSteps, stepsDelta = :delta WHERE id = :id")
    suspend fun close(id: Long, end: Long, endSteps: Int, delta: Int)

    @Query("SELECT * FROM step_sessions ORDER BY sessionStart DESC LIMIT :limit")
    fun observeRecent(limit: Int = 50): Flow<List<StepSessionEntity>>
}