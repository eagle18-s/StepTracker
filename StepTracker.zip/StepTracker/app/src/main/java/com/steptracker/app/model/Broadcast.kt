package com.steptracker.app.model

/**
 * Broadcast mesaj — StepTrackerBroadcast companion app-dən göndərilir,
 * əsas proqramda yuxarı pəncərədə göstərilir.
 *
 * Hər iki app eyni "external storage"-dəki broadcast_messages.json faylından
 * oxuyur / yazır (shared storage pattern).
 */
data class BroadcastMessage(
    val id: String,
    val title: String,
    val body: String,
    val imageUrl: String? = null,
    val actionUrl: String? = null,
    val priority: Int = 0,
    val sentAt: Long = System.currentTimeMillis(),
    val expiresAt: Long? = null
)

data class LeaderboardEntry(
    val rank: Int,
    val uid: String,
    val displayName: String,
    val photoUrl: String?,
    val steps: Long,
    val isFriend: Boolean = false,
    val isSelf: Boolean = false
)