package com.steptracker.app.ui.home

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.steptracker.app.R
import com.steptracker.app.StepTrackerApplication
import com.steptracker.app.databinding.FragmentHomeBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * Ana səhifə — bugünkü addım, kalori, məsafə, məqsəd barı və quick stats.
 */
class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val viewModel: HomeViewModel by viewModels()

    private val notifPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* ignore — user choice */ }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val app = requireActivity().application as StepTrackerApplication

        // İstifadəçi başlıq şəkli
        lifecycleScope.launch {
            val user = app.authRepository.getCurrentUserCached() ?: return@launch
            binding.greeting.text = getString(R.string.greeting, user.displayName)
            if (!user.photoUrl.isNullOrBlank()) {
                Glide.with(this@HomeFragment).load(user.photoUrl).circleCrop()
                    .into(binding.avatar)
            }
            viewModel.setUser(user)
        }

        binding.refreshLayout.setOnRefreshListener {
            viewModel.refresh(requireContext().applicationContext as StepTrackerApplication)
        }

        // Bugünkü addım məlumatlarını izləyirik
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.todayState.collectLatest { state ->
                renderState(state)
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(requireContext(),
                Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        binding.btnQuickStart.setOnClickListener {
            com.steptracker.app.service.StepCounterService.start(requireContext())
            viewModel.refresh(requireContext().applicationContext as StepTrackerApplication)
        }
    }

    private fun renderState(state: HomeViewModel.HomeState) {
        binding.refreshLayout.isRefreshing = state.loading
        binding.stepsValue.text = state.steps.toString()
        binding.caloriesValue.text = getString(R.string.kcal_value, state.calories)
        binding.distanceValue.text = getString(R.string.km_value, state.distanceKm)
        binding.activeMinutesValue.text = state.activeMinutes.toString()
        binding.goalProgress.progress = state.goalPercent.coerceAtMost(100)
        binding.goalProgressText.text = getString(R.string.goal_percent, state.goalPercent)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}