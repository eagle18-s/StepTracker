package com.steptracker.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.steptracker.app.R
import com.steptracker.app.StepTrackerApplication
import com.steptracker.app.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * LeaderboardWidgetProvider — dostlar arası top 5 leaderboard'u göstərən widget.
 *
 * Yeniləmə: STEP_WIDGET_REFRESH ilə eyni anda (hər 30 dəq + sensor update).
 */
class LeaderboardWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id -> updateWidget(context, manager, id) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == "com.steptracker.app.LEADERBOARD_WIDGET_REFRESH") {
            val manager = AppWidgetManager.getInstance(context)
            val component = ComponentName(context, LeaderboardWidgetProvider::class.java)
            val ids = manager.getAppWidgetIds(component)
            onUpdate(context, manager, ids)
        }
    }

    private fun updateWidget(context: Context, manager: AppWidgetManager, id: Int) {
        val views = RemoteViews(context.packageName, R.layout.widget_leaderboard)
        val openIntent = Intent(context, MainActivity::class.java)
        val pi = PendingIntent.getActivity(
            context, 0, openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        views.setOnClickPendingIntent(R.id.widgetRoot, pi)

        val app = context.applicationContext as? StepTrackerApplication ?: run {
            manager.updateAppWidget(id, views); return
        }

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val uid = app.authRepository.currentUid() ?: return@launch
                val friends = kotlinx.coroutines.flow.first(app.friendRepository.observeFriends(uid))
                val friendUids = friends.map { it.uid }
                val entries = app.leaderboardRepository.friendsLeaderboard(uid, friendUids).take(5)

                views.setTextViewText(R.id.widgetTitle, context.getString(R.string.tab_friends))

                if (entries.isEmpty()) {
                    views.setTextViewText(R.id.widgetLine1, context.getString(R.string.widget_empty))
                    views.setTextViewText(R.id.widgetLine2, "")
                    views.setTextViewText(R.id.widgetLine3, "")
                    views.setTextViewText(R.id.widgetLine4, "")
                    views.setTextViewText(R.id.widgetLine5, "")
                } else {
                    fun line(e: com.steptracker.app.model.LeaderboardEntry?): String {
                        if (e == null) return ""
                        return "#${e.rank} ${e.displayName} — ${e.steps}"
                    }
                    views.setTextViewText(R.id.widgetLine1, line(entries.getOrNull(0)))
                    views.setTextViewText(R.id.widgetLine2, line(entries.getOrNull(1)))
                    views.setTextViewText(R.id.widgetLine3, line(entries.getOrNull(2)))
                    views.setTextViewText(R.id.widgetLine4, line(entries.getOrNull(3)))
                    views.setTextViewText(R.id.widgetLine5, line(entries.getOrNull(4)))
                }
                manager.updateAppWidget(id, views)
            } catch (t: Throwable) {
                manager.updateAppWidget(id, views)
            }
        }
    }
}