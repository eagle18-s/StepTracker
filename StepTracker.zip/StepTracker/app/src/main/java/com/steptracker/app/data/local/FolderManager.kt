package com.steptracker.app.data.local

import android.content.Context
import android.content.SharedPreferences
import android.os.Environment
import com.steptracker.app.util.Constants
import timber.log.Timber
import java.io.File

/**
 * FolderManager — StepTracker-in bütün lokal məlumatlarını saxladığı qovluğu idarə edir.
 *
 * Yerləşmə: /storage/emulated/0/StepTrackerData/
 *  ├── daily_steps/    (gündəlik addım JSON-ları)
 *  ├── sessions/       (step sensor sessionları)
 *  ├── backups/        (auto-backup faylları)
 *  ├── preferences.xml (app prefs)
 *  └── user_profile.json
 *
 * İstifadəçi bu qovluğu manual silərsə, proqram açılanda aşkar edilir və
 * istifadəçiyə xəbərdarlıq göstərilir.
 */
class FolderManager(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(Constants.FILE_PREFERENCES, Context.MODE_PRIVATE)

    /**
     * Root app folder.
     */
    val rootFolder: File
        get() = File(Environment.getExternalStorageDirectory(), Constants.APP_FOLDER_NAME)

    val dailyStepsFolder: File get() = File(rootFolder, Constants.SUBFOLDER_DAILY)
    val sessionsFolder: File get() = File(rootFolder, Constants.SUBFOLDER_SESSIONS)
    val backupsFolder: File get() = File(rootFolder, Constants.SUBFOLDER_BACKUPS)

    /**
     * Folder-in mövcudluğunu yoxlayır, yoxdursa yaradır.
     * Silinib silinmədiyini SharedPreferences-ə yazır ki,
     * proqram açılanda xəbərdarlıq göstərək.
     */
    fun ensureAppFolderExists(): Boolean {
        val existed = rootFolder.exists()
        if (!existed) {
            // Folder silinmişdi — qeyd et ki açılanda xəbərdarlıq edək
            prefs.edit().putBoolean(Constants.PREF_FOLDER_DELETED_FLAG, true).apply()
        } else {
            prefs.edit().putBoolean(Constants.PREF_FOLDER_DELETED_FLAG, false).apply()
        }
        val ok = rootFolder.exists() || rootFolder.mkdirs()
        dailyStepsFolder.mkdirs()
        sessionsFolder.mkdirs()
        backupsFolder.mkdirs()
        Timber.d("App folder ensured at ${rootFolder.absolutePath} (ok=$ok)")
        return ok
    }

    /**
     * Folder silinib? (proqram açılanda yoxlanılır)
     */
    fun wasFolderDeleted(): Boolean {
        return !rootFolder.exists() && prefs.getBoolean(Constants.PREF_FOLDER_DELETED_FLAG, false)
    }

    /**
     * Folder silinib silinmədiyini canlı yoxla.
     */
    fun isFolderMissing(): Boolean = !rootFolder.exists()

    /**
     * Xəbərdarlıq göstərildikdən sonra bayrağı sıfırla.
     */
    fun clearDeletedFlag() {
        prefs.edit().putBoolean(Constants.PREF_FOLDER_DELETED_FLAG, false).apply()
    }

    /**
     * Folder mövcudluğunu real-time izləmək üçün istifadə olunur.
     * Hər 5 saniyədən bir folder-i yoxlayır.
     */
    fun checkFolderStateAndNotify(callback: (Boolean) -> Unit) {
        val missing = isFolderMissing()
        callback(missing)
        if (missing) {
            prefs.edit().putBoolean(Constants.PREF_FOLDER_DELETED_FLAG, true).apply()
        }
    }

    /**
     * Gündəlik addım JSON faylı.
     */
    fun dailyStepFile(dayKey: String): File =
        File(dailyStepsFolder, "steps_$dayKey.json")

    /**
     * İstifadəçi profili JSON faylı.
     */
    val userProfileFile: File get() = File(rootFolder, "user_profile.json")

    /**
     * Folder ölçüsü (MB).
     */
    fun folderSizeMb(): Double {
        if (!rootFolder.exists()) return 0.0
        var size = 0L
        rootFolder.walkTopDown().forEach { f ->
            if (f.isFile) size += f.length()
        }
        return size / (1024.0 * 1024.0)
    }
}