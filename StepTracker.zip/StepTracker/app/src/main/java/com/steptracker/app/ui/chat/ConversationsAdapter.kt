package com.steptracker.app.ui.chat

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.steptracker.app.databinding.ItemConversationBinding
import com.steptracker.app.model.Conversation
import com.steptracker.app.util.DateUtils

class ConversationsAdapter(
    private val onClick: (Conversation) -> Unit
) : ListAdapter<Conversation, ConversationsAdapter.VH>(Diff) {

    class VH(val b: ItemConversationBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemConversationBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val c = getItem(position)
        holder.b.lastMessage.text = c.lastMessage
        holder.b.time.text = DateUtils.displayTime(c.lastMessageAt)
        holder.b.unreadCount.text = c.unreadCountFor.values.sum().toString()
        holder.b.unreadCount.visibility = if (c.unreadCountFor.values.sum() > 0)
            android.view.View.VISIBLE else android.view.View.GONE
        holder.b.root.setOnClickListener { onClick(c) }
    }

    object Diff : DiffUtil.ItemCallback<Conversation>() {
        override fun areItemsTheSame(a: Conversation, b: Conversation) = a.id == b.id
        override fun areContentsTheSame(a: Conversation, b: Conversation) = a == b
    }
}