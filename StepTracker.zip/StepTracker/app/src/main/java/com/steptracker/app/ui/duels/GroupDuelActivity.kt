package com.steptracker.app.ui.duels

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.steptracker.app.databinding.ActivityGroupDuelBinding

/**
 * Boş qrup düello ekranı — birbaşa DuelsFragment-dən dialog açılır,
 * bu activity yalnız dərin bağlantı (deep link) üçündür.
 */
class GroupDuelActivity : AppCompatActivity() {
    private lateinit var binding: ActivityGroupDuelBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGroupDuelBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.toolbar.setNavigationOnClickListener { finish() }
    }
}