package com.steptracker.app.model

import java.util.Date

/**
 * İstifadəçi profili — Firebase-də və local prefs-də saxlanılır.
 */
data class User(
    val uid: String,
    val email: String,
    val displayName: String,
    val photoUrl: String? = null,
    val phoneNumber: String? = null,
    val phoneVerified: Boolean = false,
    val heightCm: Double = 170.0,
    val weightKg: Double = 70.0,
    val age: Int = 30,
    val isMale: Boolean = true,
    val stepGoal: Int = 8000,
    val dailyStepBaseline: Long = 0,    // day rollover üçün sensor baseline
    val baselineDate: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val lastActiveAt: Long = System.currentTimeMillis(),
    val fcmToken: String? = null
)

/**
 * Dostluq sorğusu və statusu.
 */
data class Friend(
    val uid: String,
    val displayName: String,
    val email: String,
    val photoUrl: String?,
    val status: FriendStatus = FriendStatus.NONE,
    val createdAt: Long = System.currentTimeMillis()
)

enum class FriendStatus {
    NONE,           // əlaqə yoxdur
    PENDING_OUT,    // mən sorğu göndərmişəm
    PENDING_IN,     // mənə sorğu gəlib
    ACCEPTED,       // dost
    BLOCKED
}

data class FriendRequest(
    val requestId: String,
    val fromUid: String,
    val fromName: String,
    val fromPhoto: String?,
    val toUid: String,
    val toName: String,
    val message: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val status: FriendStatus = FriendStatus.PENDING_IN
)