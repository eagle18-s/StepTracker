package com.steptracker.app.ui.duels

import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.firebase.firestore.FirebaseFirestore
import com.steptracker.app.R
import com.steptracker.app.StepTrackerApplication
import com.steptracker.app.databinding.ActivityDuelDetailBinding
import com.steptracker.app.databinding.ItemDuelParticipantBinding
import com.steptracker.app.model.Duel
import com.steptracker.app.model.DuelParticipant
import com.steptracker.app.util.DateUtils
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class DuelDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDuelDetailBinding
    private lateinit var adapter: ParticipantsAdapter
    private var duelId: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDuelDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        duelId = intent.getStringExtra("duelId") ?: run { finish(); return }

        adapter = ParticipantsAdapter()
        binding.recycler.layoutManager = LinearLayoutManager(this)
        binding.recycler.adapter = adapter

        binding.toolbar.setNavigationOnClickListener { finish() }

        val app = application as StepTrackerApplication
        lifecycleScope.launch {
            app.duelRepository.observeActiveDuels(app.authRepository.currentUid() ?: "").collectLatest { duels ->
                val duel = duels.firstOrNull { it.id == duelId } ?: loadDuelOnce(duelId)
                duel?.let { render(it) }
            }
        }
    }

    private suspend fun loadDuelOnce(id: String): Duel? {
        return try {
            val doc = FirebaseFirestore.getInstance().collection("duels").document(id).get().await()
            doc.toObject(Duel::class.java)
        } catch (t: Throwable) { null }
    }

    private fun render(d: Duel) {
        binding.titleText.text = d.title
        binding.timeText.text = "Bitir: " + DateUtils.displayDateTime(d.endAt)
        binding.statusText.text = when (d.status.name) {
            "ACTIVE" -> "Aktiv"
            "PENDING" -> "Gözləyir"
            "FINISHED" -> "Bitib — qalib: " + (d.winnerUid ?: "-")
            else -> d.status.name
        }
        adapter.submitList(d.participants.sortedByDescending { it.steps })
    }
}

class ParticipantsAdapter : RecyclerView.Adapter<ParticipantsAdapter.VH>() {
    private val items = mutableListOf<DuelParticipant>()

    fun submitList(list: List<DuelParticipant>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    class VH(val b: ItemDuelParticipantBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemDuelParticipantBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val p = items[position]
        holder.b.name.text = p.displayName
        holder.b.steps.text = "${p.steps} addım"
        if (!p.photoUrl.isNullOrBlank()) {
            Glide.with(holder.b.avatar).load(p.photoUrl).circleCrop().into(holder.b.avatar)
        } else {
            holder.b.avatar.setImageResource(R.drawable.ic_profile_placeholder)
        }
    }

    override fun getItemCount(): Int = items.size
}