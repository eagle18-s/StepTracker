package com.steptracker.app.data.local

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Folder silinməsini izləyən broadcast receiver.
 * Əsasən media-scanner tamamlandıqda və ya storage eventlərində tetiklenir.
 */
class FolderWatchReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val fm = FolderManager(context)
        // Folder yoxlanışı — silinmiş olarsa flag qaldır
        fm.checkFolderStateAndNotify { missing ->
            if (missing) {
                // Splash açılanda FolderRestoreActivity yönləndirəcək
            }
        }
    }
}