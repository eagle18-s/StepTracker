package com.steptracker.app.ui.chat

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.steptracker.app.R
import com.steptracker.app.StepTrackerApplication
import com.steptracker.app.databinding.ActivityChatBinding
import com.steptracker.app.model.Message
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class ChatActivity : AppCompatActivity() {

    private lateinit var binding: ActivityChatBinding
    private lateinit var adapter: MessagesAdapter
    private var friendUid: String = ""
    private var myUid: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChatBinding.inflate(layoutInflater)
        setContentView(binding.root)

        friendUid = intent.getStringExtra("friendUid") ?: run { finish(); return }
        val friendName = intent.getStringExtra("friendName") ?: getString(R.string.chat_unknown)

        binding.toolbar.title = friendName
        binding.toolbar.setNavigationOnClickListener { finish() }

        myUid = (application as StepTrackerApplication).authRepository.currentUid() ?: run { finish(); return }

        adapter = MessagesAdapter(myUid)
        val lm = LinearLayoutManager(this).apply { stackFromEnd = true }
        binding.recycler.layoutManager = lm
        binding.recycler.adapter = adapter

        binding.btnSend.setOnClickListener {
            val text = binding.messageInput.text.toString().trim()
            if (text.isEmpty()) return@setOnClickListener
            sendMessage(text)
            binding.messageInput.setText("")
        }

        observeMessages()
        lifecycleScope.launch {
            val friend = (application as StepTrackerApplication).friendRepository.findUserByUid(friendUid)
            if (friend != null) {
                binding.friendNameText.text = friend.displayName
                if (!friend.photoUrl.isNullOrBlank()) {
                    Glide.with(this@ChatActivity).load(friend.photoUrl).circleCrop().into(binding.friendAvatar)
                }
            }
        }
    }

    private fun observeMessages() {
        val repo = (application as StepTrackerApplication).messageRepository
        lifecycleScope.launch {
            repo.observeMessages(myUid, friendUid).collectLatest { msgs ->
                adapter.submitList(msgs) {
                    if (msgs.isNotEmpty()) binding.recycler.scrollToPosition(msgs.size - 1)
                }
                // Oxunmuş kimi işarələ
                repo.markRead(repo.conversationId(myUid, friendUid), myUid)
            }
        }
    }

    private fun sendMessage(text: String) {
        val app = application as StepTrackerApplication
        lifecycleScope.launch { app.messageRepository.sendMessage(myUid, friendUid, text) }
    }
}