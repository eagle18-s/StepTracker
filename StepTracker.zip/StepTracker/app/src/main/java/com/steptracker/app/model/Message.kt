package com.steptracker.app.model

import java.util.Date

/**
 * 1v1 mesaj.
 */
data class Message(
    val id: String,
    val conversationId: String, // "uid_a__uid_b" (sorted)
    val fromUid: String,
    val toUid: String,
    val text: String,
    val imageUrl: String? = null,
    val sentAt: Long = System.currentTimeMillis(),
    val deliveredAt: Long? = null,
    val readAt: Long? = null
)

/**
 * Söhbət (chat) üçün metadata.
 */
data class Conversation(
    val id: String,
    val participants: List<String>,  // [uid_a, uid_b]
    val lastMessage: String,
    val lastMessageAt: Long,
    val lastSenderUid: String,
    val unreadCountFor: Map<String, Int>  // uid -> unread count
)