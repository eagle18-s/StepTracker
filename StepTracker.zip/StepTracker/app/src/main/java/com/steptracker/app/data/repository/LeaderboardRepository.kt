package com.steptracker.app.data.repository

import com.google.firebase.firestore.FirebaseFirestore
import com.steptracker.app.model.LeaderboardEntry
import com.steptracker.app.util.DateUtils
import kotlinx.coroutines.tasks.await
import timber.log.Timber

/**
 * Leaderboard repository — iki növ:
 *  1) Dostlar arası leaderboard
 *  2) Ümumi (qlobal) leaderboard
 *
 * Addım məlumatları lokal olsa da, gündəlik cəm Firestore-da bir snapshot kimi
 * "dailySteps" collection-unda saxlanılır ki, dostlar və qlobal leaderboard
 * müqayisə edə bilsin. Snapshot yalnız cari gün üçündür və 24 saat sonra silinir.
 */
class LeaderboardRepository {

    private val db = FirebaseFirestore.getInstance()

    /**
     * Cari gün üçün öz addım cəmimi Firestore-a snapshot olaraq yazır.
     * StepRepository.saveToday çağırıldıqda StepCounterService-dən trigger olunur.
     */
    suspend fun publishDailySnapshot(uid: String, displayName: String, photoUrl: String?,
                                     steps: Long) {
        try {
            val today = DateUtils.dayKey()
            db.collection("dailySteps").document("$today__$uid").set(
                mapOf(
                    "uid" to uid,
                    "displayName" to displayName,
                    "photoUrl" to photoUrl,
                    "steps" to steps,
                    "dayKey" to today,
                    "updatedAt" to System.currentTimeMillis()
                )
            ).await()
        } catch (t: Throwable) {
            Timber.w(t, "publishDailySnapshot failed")
        }
    }

    /**
     * Dostlar arası leaderboard — cari gün üçün.
     * Yalnız qəbul edilmiş dostların snapshot-larını çəkir.
     */
    suspend fun friendsLeaderboard(myUid: String, friendUids: List<String>): List<LeaderboardEntry> {
        if (friendUids.isEmpty()) return emptyList()
        val today = DateUtils.dayKey()
        val allUids = (listOf(myUid) + friendUids).distinct()
        val entries = mutableListOf<LeaderboardEntry>()

        // Firestore "in" query 10-a qədər dəstəkləyir, batch-lə
        allUids.chunked(10).forEach { batch ->
            val ids = batch.map { "$today__$it" }
            val snap = db.collection("dailySteps")
                .whereIn(com.google.firebase.firestore.FieldPath.documentId(), ids)
                .get().await()
            for (doc in snap.documents) {
                val data = doc.data ?: continue
                val uid = data["uid"] as? String ?: continue
                val steps = (data["steps"] as? Long) ?: 0L
                val name = data["displayName"] as? String ?: ""
                val photo = data["photoUrl"] as? String
                entries.add(LeaderboardEntry(
                    rank = 0,
                    uid = uid,
                    displayName = name,
                    photoUrl = photo,
                    steps = steps,
                    isFriend = uid != myUid,
                    isSelf = uid == myUid
                ))
            }
        }

        return entries.sortedByDescending { it.steps }
            .mapIndexed { idx, e -> e.copy(rank = idx + 1) }
    }

    /**
     * Ümumi (qlobal) leaderboard — Top N.
     */
    suspend fun globalLeaderboard(limit: Int = 100): List<LeaderboardEntry> {
        val today = DateUtils.dayKey()
        val prefix = "$today__"
        val snap = db.collection("dailySteps")
            .whereGreaterThan(com.google.firebase.firestore.FieldPath.documentId(), prefix)
            .whereLessThan(com.google.firebase.firestore.FieldPath.documentId(), "$prefix~")
            .orderBy(com.google.firebase.firestore.FieldPath.documentId())
            .orderBy("steps", com.google.firebase.firestore.Query.Direction.DESCENDING)
            .limit(limit.toLong())
            .get().await()
        val list = snap.documents.mapNotNull { doc ->
            val data = doc.data ?: return@mapNotNull null
            LeaderboardEntry(
                rank = 0,
                uid = data["uid"] as? String ?: return@mapNotNull null,
                displayName = data["displayName"] as? String ?: "",
                photoUrl = data["photoUrl"] as? String,
                steps = (data["steps"] as? Long) ?: 0L,
                isFriend = false,
                isSelf = false
            )
        }
        return list.mapIndexed { idx, e -> e.copy(rank = idx + 1) }
    }

    /**
     * Cari istifadəçinin qlobal reytinqi.
     */
    suspend fun myGlobalRank(myUid: String, mySteps: Long): Int? {
        val today = DateUtils.dayKey()
        val prefix = "$today__"
        val snap = db.collection("dailySteps")
            .whereGreaterThan(com.google.firebase.firestore.FieldPath.documentId(), prefix)
            .whereLessThan(com.google.firebase.firestore.FieldPath.documentId(), "$prefix~")
            .whereGreaterThan("steps", mySteps)
            .get().await()
        return snap.size() + 1
    }
}