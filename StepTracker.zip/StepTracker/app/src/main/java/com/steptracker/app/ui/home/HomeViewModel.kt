package com.steptracker.app.ui.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.steptracker.app.StepTrackerApplication
import com.steptracker.app.model.User
import com.steptracker.app.util.CalorieCalculator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class HomeViewModel(app: Application) : AndroidViewModel(app) {

    data class HomeState(
        val loading: Boolean = false,
        val steps: Int = 0,
        val calories: Double = 0.0,
        val distanceKm: Double = 0.0,
        val activeMinutes: Int = 0,
        val goalPercent: Int = 0,
        val user: User? = null
    )

    private val _todayState = MutableStateFlow(HomeState())
    val todayState: StateFlow<HomeState> = _todayState.asStateFlow()

    init {
        refresh(app as StepTrackerApplication)
    }

    fun setUser(user: User) {
        _todayState.value = _todayState.value.copy(user = user)
    }

    fun refresh(app: StepTrackerApplication) {
        viewModelScope.launch {
            _todayState.value = _todayState.value.copy(loading = true)
            val user = app.authRepository.getCurrentUserCached()
            app.stepRepository.observeToday().collectLatest { entity ->
                val steps = entity?.steps ?: 0
                val weight = user?.weightKg ?: com.steptracker.app.util.Constants.DEFAULT_USER_WEIGHT_KG
                val height = user?.heightCm ?: com.steptracker.app.util.Constants.DEFAULT_USER_HEIGHT_CM
                val isMale = user?.isMale ?: true
                val goal = user?.stepGoal ?: com.steptracker.app.util.Constants.DEFAULT_STEP_GOAL

                val distanceM = CalorieCalculator.distanceMeters(steps, height, isMale)
                val calories = CalorieCalculator.calculateWithElevation(
                    steps, weight, entity?.elevationGainMeters ?: 0.0
                )
                val activeMin = CalorieCalculator.activeMinutes(steps)
                val percent = CalorieCalculator.goalProgressPercent(steps, goal)

                _todayState.value = HomeState(
                    loading = false,
                    steps = steps,
                    calories = calories,
                    distanceKm = distanceM / 1000.0,
                    activeMinutes = activeMin,
                    goalPercent = percent,
                    user = user
                )

                // Snapshot-u Firestore-a yaz ki, dostlar / leaderboard görə bilsin
                user?.let { u ->
                    app.leaderboardRepository.publishDailySnapshot(
                        uid = u.uid,
                        displayName = u.displayName,
                        photoUrl = u.photoUrl,
                        steps = steps.toLong()
                    )
                }
            }
        }
    }
}