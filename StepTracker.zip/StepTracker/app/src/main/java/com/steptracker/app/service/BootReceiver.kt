package com.steptracker.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.steptracker.app.StepTrackerApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import timber.log.Timber

/**
 * Telefon yandırılanda və ya app yenilənəndə step service-i avtomatik başladır.
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_LOCKED_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED -> {
                val pendingResult = goAsync()
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        val app = context.applicationContext as? StepTrackerApplication
                        val isAuthed = app?.authRepository?.isSignedIn() ?: false
                        if (isAuthed) {
                            StepCounterService.start(context)
                            Timber.d("StepCounterService auto-started after boot/update")
                        }
                    } catch (t: Throwable) {
                        Timber.w(t, "BootReceiver failed")
                    } finally {
                        try { pendingResult.finish() } catch (_: Throwable) {}
                    }
                }
            }
        }
    }
}