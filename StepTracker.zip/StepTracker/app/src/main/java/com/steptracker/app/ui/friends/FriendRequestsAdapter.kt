package com.steptracker.app.ui.friends

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.steptracker.app.databinding.ItemFriendRequestBinding
import com.steptracker.app.model.FriendRequest

class FriendRequestsAdapter(
    private val onAccept: (FriendRequest) -> Unit,
    private val onDecline: (FriendRequest) -> Unit
) : ListAdapter<FriendRequest, FriendRequestsAdapter.VH>(Diff) {

    class VH(val binding: ItemFriendRequestBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemFriendRequestBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val r = getItem(position)
        holder.binding.name.text = r.fromName
        if (!r.fromPhoto.isNullOrBlank()) {
            Glide.with(holder.binding.avatar).load(r.fromPhoto).circleCrop().into(holder.binding.avatar)
        } else {
            holder.binding.avatar.setImageResource(com.steptracker.app.R.drawable.ic_profile_placeholder)
        }
        holder.binding.btnAccept.setOnClickListener { onAccept(r) }
        holder.binding.btnDecline.setOnClickListener { onDecline(r) }
    }

    object Diff : DiffUtil.ItemCallback<FriendRequest>() {
        override fun areItemsTheSame(a: FriendRequest, b: FriendRequest) = a.requestId == b.requestId
        override fun areContentsTheSame(a: FriendRequest, b: FriendRequest) = a == b
    }
}