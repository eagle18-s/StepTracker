package com.steptracker.app.ui.friends

import android.app.Application
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.steptracker.app.R
import com.steptracker.app.StepTrackerApplication
import com.steptracker.app.model.Friend
import com.steptracker.app.model.FriendRequest
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class FriendsViewModel(app: Application) : AndroidViewModel(app) {

    private val _friends = MutableStateFlow<List<Friend>>(emptyList())
    val friends: StateFlow<List<Friend>> = _friends.asStateFlow()

    private val _requests = MutableStateFlow<List<FriendRequest>>(emptyList())
    val requests: StateFlow<List<FriendRequest>> = _requests.asStateFlow()

    private var uid: String? = null

    fun load(app: StepTrackerApplication) {
        uid = app.authRepository.currentUid() ?: return
        viewModelScope.launch {
            app.friendRepository.observeFriends(uid!!).collectLatest { _friends.value = it }
        }
        viewModelScope.launch {
            app.friendRepository.observeIncomingRequests(uid!!).collectLatest { _requests.value = it }
        }
    }

    fun sendRequestByEmail(app: StepTrackerApplication, email: String) {
        val fromUid = uid ?: return
        viewModelScope.launch {
            val user = app.authRepository.getCurrentUserCached() ?: return@launch
            val target = app.friendRepository.findUserByEmail(email)
            if (target == null) {
                Toast.makeText(app, R.string.user_not_found, Toast.LENGTH_SHORT).show()
                return@launch
            }
            if (target.uid == fromUid) {
                Toast.makeText(app, R.string.cannot_add_self, Toast.LENGTH_SHORT).show()
                return@launch
            }
            val ok = app.friendRepository.sendFriendRequest(
                fromUid = fromUid,
                fromName = user.displayName,
                fromPhoto = user.photoUrl,
                toUid = target.uid,
                toName = target.displayName
            )
            val msg = if (ok) R.string.request_sent else R.string.request_already_exists
            Toast.makeText(app, msg, Toast.LENGTH_SHORT).show()
        }
    }

    fun acceptRequest(app: StepTrackerApplication, req: FriendRequest) {
        viewModelScope.launch {
            app.friendRepository.acceptFriendRequest(
                req.requestId, req.fromUid, req.fromName, req.fromPhoto,
                req.toUid, req.toName
            )
        }
    }

    fun declineRequest(app: StepTrackerApplication, req: FriendRequest) {
        viewModelScope.launch { app.friendRepository.declineFriendRequest(req.requestId) }
    }

    fun removeFriend(app: StepTrackerApplication, friendUid: String) {
        val fromUid = uid ?: return
        viewModelScope.launch { app.friendRepository.removeFriend(fromUid, friendUid) }
    }
}