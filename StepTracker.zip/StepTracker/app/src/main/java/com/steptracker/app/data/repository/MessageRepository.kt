package com.steptracker.app.data.repository

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.steptracker.app.model.Conversation
import com.steptracker.app.model.Message
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import timber.log.Timber

/**
 * Mesajlaşma repository — Firestore "conversations" və "messages" collection-ları.
 *
 * Conversation id formatı: sorted(uid_a, uid_b).join("__")
 */
class MessageRepository {

    private val db = FirebaseFirestore.getInstance()

    fun conversationId(uidA: String, uidB: String): String {
        val sorted = listOf(uidA, uidB).sorted()
        return "${sorted[0]}__${sorted[1]}"
    }

    /**
     * Mesaj göndərir.
     */
    suspend fun sendMessage(fromUid: String, toUid: String, text: String): String? {
        if (text.isBlank()) return null
        val convId = conversationId(fromUid, toUid)
        val msg = Message(
            id = "",
            conversationId = convId,
            fromUid = fromUid,
            toUid = toUid,
            text = text.trim()
        )
        val ref = db.collection("messages").document(convId)
            .collection("items").add(msg).await()

        // Conversation metadata yenilə
        val convDoc = db.collection("conversations").document(convId)
        val conv = Conversation(
            id = convId,
            participants = listOf(fromUid, toUid),
            lastMessage = text.trim(),
            lastMessageAt = msg.sentAt,
            lastSenderUid = fromUid,
            unreadCountFor = mapOf(toUid to 1)
        )
        convDoc.set(conv).await()
        return ref.id
    }

    /**
     * Söhbətdəki mesajları izləyir.
     */
    fun observeMessages(uidA: String, uidB: String): Flow<List<Message>> = callbackFlow {
        val convId = conversationId(uidA, uidB)
        val reg = db.collection("messages").document(convId)
            .collection("items")
            .orderBy("sentAt", Query.Direction.ASCENDING)
            .addSnapshotListener { snap, err ->
                if (err != null) {
                    Timber.w(err, "observeMessages")
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                trySend(snap?.documents?.mapNotNull { it.toObject(Message::class.java) } ?: emptyList())
            }
        awaitClose { reg.remove() }
    }

    /**
     * İstifadəçinin bütün söhbətlərini izləyir.
     */
    fun observeConversations(uid: String): Flow<List<Conversation>> = callbackFlow {
        val reg = db.collection("conversations")
            .whereArrayContains("participants", uid)
            .orderBy("lastMessageAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snap, err ->
                if (err != null) {
                    Timber.w(err, "observeConversations")
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                trySend(snap?.documents?.mapNotNull { it.toObject(Conversation::class.java) } ?: emptyList())
            }
        awaitClose { reg.remove() }
    }

    /**
     * Mesajı oxunmuş kimi işarələyir.
     */
    suspend fun markRead(conversationId: String, readerUid: String) {
        val unread = mapOf(readerUid to 0)
        db.collection("conversations").document(conversationId)
            .update("unreadCountFor.$readerUid", 0).await()
    }
}