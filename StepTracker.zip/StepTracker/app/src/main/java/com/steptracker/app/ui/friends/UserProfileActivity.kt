package com.steptracker.app.ui.friends

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.steptracker.app.databinding.ActivityUserProfileBinding

/**
 * İstifadəçi profilinə baxış ekranı (dostun profilini görmək üçün).
 */
class UserProfileActivity : AppCompatActivity() {

    private lateinit var binding: ActivityUserProfileBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUserProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.toolbar.setNavigationOnClickListener { finish() }
    }
}