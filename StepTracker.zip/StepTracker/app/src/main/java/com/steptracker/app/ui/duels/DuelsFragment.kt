package com.steptracker.app.ui.duels

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.steptracker.app.R
import com.steptracker.app.StepTrackerApplication
import com.steptracker.app.databinding.FragmentDuelsBinding
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * Düellolar səhifəsi — aktiv, pending və bitmiş düellolar.
 *
 * İstifadəçinin aktiv düellosu varsa yeni duel sorğusu ata bilməz.
 */
class DuelsFragment : Fragment() {

    private var _binding: FragmentDuelsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: DuelsViewModel by viewModels()
    private lateinit var adapter: DuelsAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View {
        _binding = FragmentDuelsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val app = requireActivity().application as StepTrackerApplication

        adapter = DuelsAdapter(
            onClick = { duel ->
                startActivity(Intent(requireContext(), DuelDetailActivity::class.java)
                    .putExtra("duelId", duel.id))
            },
            onAccept = { duel -> viewModel.acceptDuel(app, duel.id) },
            onDecline = { duel -> viewModel.declineDuel(app, duel.id) },
            onWithdraw = { duel ->
                MaterialAlertDialogBuilder(requireContext())
                    .setTitle(R.string.withdraw_title)
                    .setMessage(R.string.withdraw_msg)
                    .setPositiveButton(R.string.withdraw) { _, _ ->
                        viewModel.withdrawDuel(app, duel.id)
                    }
                    .setNegativeButton(R.string.cancel, null).show()
            }
        )

        binding.recyclerDuels.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerDuels.adapter = adapter

        binding.btnNewDuel.setOnClickListener { showNewDuelDialog() }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.uiState.collectLatest { state ->
                binding.loadingBar.visibility = if (state.loading) View.VISIBLE else View.GONE
                adapter.submitList(state.sections.flatMap { it.duels })
                binding.btnNewDuel.isEnabled = !state.hasActive
                binding.btnNewDuel.text = if (state.hasActive)
                    getString(R.string.duel_active_locked) else getString(R.string.duel_new)
            }
        }

        viewModel.load(app)
    }

    private fun showNewDuelDialog() {
        val app = requireActivity().application as StepTrackerApplication
        val options = arrayOf(
            getString(R.string.duel_type_1v1),
            getString(R.string.duel_type_group)
        )
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.duel_new)
            .setItems(options) { _, which ->
                if (which == 0) showOneVsOneDialog(app) else showGroupDuelDialog(app)
            }.show()
    }

    private fun showOneVsOneDialog(app: StepTrackerApplication) {
        val input = EditText(requireContext()).apply {
            hint = getString(R.string.opponent_email_hint)
        }
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.duel_1v1_title)
            .setView(input)
            .setPositiveButton(R.string.send) { _, _ ->
                val email = input.text.toString().trim()
                if (email.isNotEmpty()) {
                    viewModel.createOneVsOneByEmail(app, email) { msg ->
                        Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showGroupDuelDialog(app: StepTrackerApplication) {
        val titleInput = EditText(requireContext()).apply {
            hint = getString(R.string.group_duel_title_hint)
        }
        val emailsInput = EditText(requireContext()).apply {
            hint = getString(R.string.group_duel_emails_hint)
            minLines = 3
            setSingleLine(false)
        }
        val container = android.widget.LinearLayout(requireContext()).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(48, 16, 48, 16)
            addView(titleInput)
            addView(emailsInput)
        }
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.group_duel_title)
            .setView(container)
            .setPositiveButton(R.string.send) { _, _ ->
                val title = titleInput.text.toString().trim()
                val emails = emailsInput.text.toString()
                    .split(",", ";", "\n")
                    .map { it.trim() }
                    .filter { it.isNotEmpty() }
                if (emails.isEmpty()) {
                    Toast.makeText(requireContext(), R.string.no_emails, Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                viewModel.createGroupDuelByEmails(app, title, emails) { msg ->
                    Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}