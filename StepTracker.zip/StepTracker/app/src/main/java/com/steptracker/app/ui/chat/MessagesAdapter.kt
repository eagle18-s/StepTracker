package com.steptracker.app.ui.chat

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.steptracker.app.R
import com.steptracker.app.databinding.ItemMessageInBinding
import com.steptracker.app.databinding.ItemMessageOutBinding
import com.steptracker.app.model.Message
import com.steptracker.app.util.DateUtils

class MessagesAdapter(private val myUid: String) :
    ListAdapter<Message, RecyclerView.ViewHolder>(Diff) {

    companion object {
        const val TYPE_IN = 1
        const val TYPE_OUT = 2
    }

    class InVH(val b: ItemMessageInBinding) : RecyclerView.ViewHolder(b.root)
    class OutVH(val b: ItemMessageOutBinding) : RecyclerView.ViewHolder(b.root)

    override fun getItemViewType(position: Int): Int =
        if (getItem(position).fromUid == myUid) TYPE_OUT else TYPE_IN

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == TYPE_OUT) {
            OutVH(ItemMessageOutBinding.inflate(LayoutInflater.from(parent.context), parent, false))
        } else {
            InVH(ItemMessageInBinding.inflate(LayoutInflater.from(parent.context), parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val m = getItem(position)
        when (holder) {
            is InVH -> {
                holder.b.messageText.text = m.text
                holder.b.time.text = DateUtils.displayTime(m.sentAt)
            }
            is OutVH -> {
                holder.b.messageText.text = m.text
                holder.b.time.text = DateUtils.displayTime(m.sentAt)
                holder.b.statusIcon.setImageResource(
                    when {
                        m.readAt != null -> R.drawable.ic_check_read
                        m.deliveredAt != null -> R.drawable.ic_check_delivered
                        else -> R.drawable.ic_check_sent
                    }
                )
            }
        }
    }

    object Diff : DiffUtil.ItemCallback<Message>() {
        override fun areItemsTheSame(a: Message, b: Message) = a.id == b.id
        override fun areContentsTheSame(a: Message, b: Message) = a == b
    }
}