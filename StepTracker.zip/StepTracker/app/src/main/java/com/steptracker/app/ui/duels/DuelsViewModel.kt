package com.steptracker.app.ui.duels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.steptracker.app.StepTrackerApplication
import com.steptracker.app.model.Duel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class DuelsViewModel(app: Application) : AndroidViewModel(app) {

    data class DuelSection(val title: String, val duels: List<Duel>)
    data class UiState(
        val loading: Boolean = false,
        val hasActive: Boolean = false,
        val sections: List<DuelSection> = emptyList()
    )

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    fun load(app: StepTrackerApplication) {
        val uid = app.authRepository.currentUid() ?: return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(loading = true)
            // Pending sorğular
            app.duelRepository.observePendingDuels(uid).collectLatest { pending ->
                val active = activeLatest(app, uid)
                val finished = finishedLatest(app, uid)
                val sections = buildList {
                    if (pending.isNotEmpty()) add(DuelSection("Gələn sorğular", pending))
                    if (active.isNotEmpty()) add(DuelSection("Aktiv düellolar", active))
                    if (finished.isNotEmpty()) add(DuelSection("Bitmiş düellolar", finished))
                }
                _uiState.value = UiState(
                    loading = false,
                    hasActive = active.isNotEmpty() || pending.isNotEmpty(),
                    sections = sections
                )
            }
        }
    }

    private suspend fun activeLatest(app: StepTrackerApplication, uid: String): List<Duel> {
        return try {
            // observeActiveDuels Flow birbaşa qaytarır — amma burada snapshot lazımdır
            kotlinx.coroutines.flow.first(app.duelRepository.observeActiveDuels(uid))
        } catch (t: Throwable) { emptyList() }
    }

    private suspend fun finishedLatest(app: StepTrackerApplication, uid: String): List<Duel> {
        return try {
            kotlinx.coroutines.flow.first(app.duelRepository.observeFinishedDuels(uid))
        } catch (t: Throwable) { emptyList() }
    }

    fun acceptDuel(app: StepTrackerApplication, duelId: String) {
        val uid = app.authRepository.currentUid() ?: return
        viewModelScope.launch { app.duelRepository.acceptDuel(duelId, uid) }
    }

    fun declineDuel(app: StepTrackerApplication, duelId: String) {
        viewModelScope.launch { app.duelRepository.declineDuel(duelId) }
    }

    fun withdrawDuel(app: StepTrackerApplication, duelId: String) {
        viewModelScope.launch { app.duelRepository.withdrawDuel(duelId) }
    }

    fun createOneVsOneByEmail(app: StepTrackerApplication, email: String, cb: (String) -> Unit) {
        val uid = app.authRepository.currentUid() ?: return
        viewModelScope.launch {
            val user = app.authRepository.getCurrentUserCached() ?: return@launch
            val target = app.friendRepository.findUserByEmail(email)
            if (target == null) {
                cb("İstifadəçi tapılmadı"); return@launch
            }
            if (target.uid == uid) {
                cb("Özünüzlə duel ola bilməz"); return@launch
            }
            val id = app.duelRepository.createOneVsOneDuel(
                challengerUid = uid,
                challengerName = user.displayName,
                challengerPhoto = user.photoUrl,
                opponentUid = target.uid,
                opponentName = target.displayName
            )
            cb(if (id != null) "Düello sorğusu göndərildi" else "Düello yaradıla bilmədi (aktiv duel var)")
        }
    }

    fun createGroupDuelByEmails(app: StepTrackerApplication, title: String, emails: List<String>,
                                 cb: (String) -> Unit) {
        val uid = app.authRepository.currentUid() ?: return
        viewModelScope.launch {
            val user = app.authRepository.getCurrentUserCached() ?: return@launch
            if (emails.size > 9) { cb("Maksimum 9 dəvət edilə bilər (10 nəfərlik limit)"); return@launch }
            if (emails.size < 1) { cb("Ən azı 1 dəvət lazımdır"); return@launch }

            val uids = mutableListOf<String>()
            for (email in emails) {
                val u = app.friendRepository.findUserByEmail(email)
                if (u == null) { cb("$email tapılmadı"); return@launch }
                if (u.uid == uid) { cb("Özünüzü dəvət edə bilməzsiniz"); return@launch }
                uids.add(u.uid)
            }
            val id = app.duelRepository.createGroupDuel(
                challengerUid = uid,
                challengerName = user.displayName,
                challengerPhoto = user.photoUrl,
                title = title,
                inviteUids = uids
            )
            cb(if (id != null) "Qrup düellosu yaradıldı" else "Düello yaradıla bilmədi")
        }
    }
}