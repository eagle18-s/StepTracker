package com.steptracker.app.ui.auth

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.RadioButton
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.steptracker.app.R
import com.steptracker.app.StepTrackerApplication
import com.steptracker.app.databinding.ActivityProfileSetupBinding
import com.steptracker.app.ui.MainActivity
import kotlinx.coroutines.launch

/**
 * Profil qurma ekranı — bütün məlumatlar burada doldurulur:
 *  - Ekran adı
 *  - Boy (cm)
 *  - Çəki (kg)
 *  - Yaş
 *  - Cins
 *  - Gündəlik addım məqsədi
 *  - Profil şəkli (Google-dan gələn)
 */
class ProfileSetupActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProfileSetupBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileSetupBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Mövcud istifadəçini göstər
        val app = application as StepTrackerApplication
        lifecycleScope.launch {
            val user = app.authRepository.getCurrentUserCached() ?: return@launch
            binding.nameInput.setText(user.displayName)
            binding.heightInput.setText(user.heightCm.toInt().toString())
            binding.weightInput.setText(user.weightKg.toInt().toString())
            binding.ageInput.setText(user.age.toString())
            if (user.isMale) binding.genderMale.isChecked = true else binding.genderFemale.isChecked = true
            binding.goalSlider.value = user.stepGoal.toFloat().coerceIn(1000f, 30000f)
            if (!user.photoUrl.isNullOrBlank()) {
                Glide.with(this@ProfileSetupActivity).load(user.photoUrl).circleCrop()
                    .into(binding.profileImage)
            }
        }

        binding.goalValue.text = getString(R.string.goal_value, binding.goalSlider.value.toInt())
        binding.goalSlider.addOnChangeListener { _, value, _ ->
            binding.goalValue.text = getString(R.string.goal_value, value.toInt())
        }

        binding.nameInput.addTextChangedListener(textWatcher { validate() })
        binding.heightInput.addTextChangedListener(textWatcher { validate() })
        binding.weightInput.addTextChangedListener(textWatcher { validate() })
        binding.ageInput.addTextChangedListener(textWatcher { validate() })

        binding.btnContinue.setOnClickListener { saveProfile() }
    }

    private fun textWatcher(cb: () -> Unit) = object : TextWatcher {
        override fun afterTextChanged(s: Editable?) = cb()
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
    }

    private fun validate(): Boolean {
        val name = binding.nameInput.text.toString().trim()
        val h = binding.heightInput.text.toString().toDoubleOrNull() ?: 0.0
        val w = binding.weightInput.text.toString().toDoubleOrNull() ?: 0.0
        val a = binding.ageInput.text.toString().toIntOrNull() ?: 0
        val ok = name.isNotEmpty() && h in 50.0..250.0 && w in 20.0..300.0 && a in 5..120
        binding.btnContinue.isEnabled = ok
        return ok
    }

    private fun saveProfile() {
        if (!validate()) return
        val isMale = (binding.genderGroup.findViewById<RadioButton>(binding.genderMale.id)).isChecked
        val app = application as StepTrackerApplication
        binding.btnContinue.isEnabled = false
        binding.progress.visibility = View.VISIBLE

        lifecycleScope.launch {
            app.authRepository.updateUserProfile(
                displayName = binding.nameInput.text.toString().trim(),
                heightCm = binding.heightInput.text.toString().toDouble(),
                weightKg = binding.weightInput.text.toString().toDouble(),
                age = binding.ageInput.text.toString().toInt(),
                isMale = isMale,
                stepGoal = binding.goalSlider.value.toInt()
            )
            startActivity(Intent(this@ProfileSetupActivity, MainActivity::class.java))
            finish()
        }
    }
}