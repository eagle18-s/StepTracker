package com.steptracker.app.ui.complaint

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.steptracker.app.R
import com.steptracker.app.StepTrackerApplication
import com.steptracker.app.databinding.ActivityComplaintBinding
import kotlinx.coroutines.launch

/**
 * Şikayət ekranı — istifadəçi yazdığı mesajı seydayev201065@gmail.com ünvanına göndərir.
 *
 * Göndərmə üsulu: e-poçt client (Intent.ACTION_SEND) vasitəsilə.
 * Əgər telefonunda mail app yoxdursa, Şikayəti Firestore "complaints" collection-unda
 * saxlayırıq ki, sonradan Cloud Function ilə email göndərə bilək (opsional).
 */
class ComplaintActivity : AppCompatActivity() {

    private lateinit var binding: ActivityComplaintBinding
    private val targetEmail = "seydayev201065@gmail.com"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityComplaintBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.toolbar.setNavigationOnClickListener { finish() }

        binding.btnSend.setOnClickListener { sendComplaint() }
    }

    private fun sendComplaint() {
        val subject = binding.subjectInput.text.toString().trim()
        val body = binding.messageInput.text.toString().trim()
        if (body.isEmpty()) {
            Toast.makeText(this, R.string.complaint_empty, Toast.LENGTH_SHORT).show()
            return
        }

        binding.btnSend.isEnabled = false
        binding.progress.visibility = android.view.View.VISIBLE

        val app = application as StepTrackerApplication
        lifecycleScope.launch {
            try {
                // Firestore-da saxla (backup)
                app.authRepository.currentUid()?.let { uid ->
                    val data = hashMapOf(
                        "uid" to uid,
                        "subject" to subject,
                        "body" to body,
                        "sentAt" to System.currentTimeMillis(),
                        "appVersion" to com.steptracker.app.BuildConfig.VERSION_NAME
                    )
                    com.google.firebase.firestore.FirebaseFirestore.getInstance()
                        .collection("complaints").add(data)
                }
            } catch (t: Throwable) { /* ignore — email intent hələ işləyəcək */ }

            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:$targetEmail")
                putExtra(Intent.EXTRA_EMAIL, arrayOf(targetEmail))
                putExtra(Intent.EXTRA_SUBJECT, subject.ifBlank { "StepTracker Şikayət" })
                putExtra(Intent.EXTRA_TEXT, body)
            }
            try {
                startActivity(Intent.createChooser(intent, getString(R.string.complaint_chooser)))
            } catch (e: android.content.ActivityNotFoundException) {
                Toast.makeText(this@ComplaintActivity, R.string.no_email_app, Toast.LENGTH_LONG).show()
            }
            binding.btnSend.isEnabled = true
            binding.progress.visibility = android.view.View.GONE
            finish()
        }
    }
}