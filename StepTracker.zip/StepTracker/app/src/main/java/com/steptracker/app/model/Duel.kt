package com.steptracker.app.model

import java.util.Date

/**
 * Düello modeli — Firebase Firestore "duels" collection-unda saxlanılır.
 *
 * @param id duel id
 * @param type 1v1 yaxud qrup (2..10 nəfər)
 * @param challengerUid duel quran şəxs
 * @param participants iştirakçıların uid-ləri
 * @param startAt başlama vaxtı (millis)
 * @param endAt bitmə vaxtı (startAt + 3 gün)
 * @param status davam edir / bitib / geri çəkilib / ləğv edilib
 * @param winnerUid qalib (yalnız status==FINISHED olduqda dolu olur)
 * @param stepsSnapshot iştirakçıların addım xülasəsi (uid -> steps)
 * @param createdAt yaranma vaxtı
 */
data class Duel(
    val id: String,
    val type: DuelType,
    val title: String,
    val challengerUid: String,
    val challengerName: String,
    val participants: List<DuelParticipant>,
    val startAt: Long,
    val endAt: Long,
    val status: DuelStatus,
    val winnerUid: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

enum class DuelType { ONE_VS_ONE, GROUP }

enum class DuelStatus {
    PENDING,        // sorğu göndərilib, qəbul olunmayıb
    ACTIVE,         // davam edir
    FINISHED,       // vaxt bitib, qalib seçildi
    WITHDRAWN,      // geri çəkildi (challenger tərəfindən ləğv)
    DECLINED        // qəbul olunmadı
}

data class DuelParticipant(
    val uid: String,
    val displayName: String,
    val photoUrl: String?,
    val steps: Long = 0,
    val joinedAt: Long = System.currentTimeMillis(),
    val hasAccepted: Boolean = false
)