package com.steptracker.app.data.repository

import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.steptracker.app.model.Duel
import com.steptracker.app.model.DuelParticipant
import com.steptracker.app.model.DuelStatus
import com.steptracker.app.model.DuelType
import com.steptracker.app.util.Constants
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import timber.log.Timber
import java.util.UUID

/**
 * Düello (step duel) repository — Firestore "duels" collection-unda saxlanılır.
 *
 * Qaydalar:
 *  - Düello 3 gün davam edir.
 *  - İstifadəçi yalnız aktiv düellosu bitdikdən və ya geri çəkildikdən sonra yeni duel
 *    sorğusu ata bilər.
 *  - Qrup düellosu 2..10 nəfər.
 *  - Addım snapshot-ları hər 5 dəqiqədən bir Firestore-a yazılır (StepCounterService-dən).
 */
class DuelRepository {

    private val db = FirebaseFirestore.getInstance()

    /**
     * İstifadəçinin aktiv düellosu var?
     */
    suspend fun hasActiveDuel(uid: String): Boolean {
        val active = db.collection("duels")
            .whereArrayContains("participantUids", uid)
            .whereEqualTo("status", DuelStatus.ACTIVE.name)
            .get().await()
        return !active.isEmpty
    }

    /**
     * 1v1 düello sorğusu göndərir.
     */
    suspend fun createOneVsOneDuel(
        challengerUid: String,
        challengerName: String,
        challengerPhoto: String?,
        opponentUid: String,
        opponentName: String
    ): String? {
        if (hasActiveDuel(challengerUid) || hasActiveDuel(opponentUid)) return null

        val now = System.currentTimeMillis()
        val endAt = now + Constants.DUEL_DURATION_DAYS * 24L * 60 * 60 * 1000

        val duel = hashMapOf(
            "type" to DuelType.ONE_VS_ONE.name,
            "title" to "$challengerName ⚔ $opponentName",
            "challengerUid" to challengerUid,
            "challengerName" to challengerName,
            "challengerPhoto" to challengerPhoto,
            "opponentUid" to opponentUid,
            "opponentName" to opponentName,
            "participantUids" to listOf(challengerUid, opponentUid),
            "participants" to listOf(
                mapOf("uid" to challengerUid, "displayName" to challengerName,
                    "photoUrl" to challengerPhoto, "steps" to 0L,
                    "joinedAt" to now, "hasAccepted" to true),
                mapOf("uid" to opponentUid, "displayName" to opponentName,
                    "photoUrl" to null, "steps" to 0L,
                    "joinedAt" to now, "hasAccepted" to false)
            ),
            "startAt" to now,
            "endAt" to endAt,
            "status" to DuelStatus.PENDING.name,
            "createdAt" to now
        )
        val ref = db.collection("duels").add(duel).await()
        return ref.id
    }

    /**
     * Qrup düellosu yaradır (2..10 nəfər).
     * İlk iştirakçı avtomatik qəbul edilmiş sayılır (challenger).
     */
    suspend fun createGroupDuel(
        challengerUid: String,
        challengerName: String,
        challengerPhoto: String?,
        title: String,
        inviteUids: List<String>
    ): String? {
        if (inviteUids.size + 1 > Constants.MAX_GROUP_DUEL_SIZE) return null
        if (inviteUids.size + 1 < Constants.MIN_GROUP_DUEL_SIZE) return null
        if (hasActiveDuel(challengerUid)) return null

        val now = System.currentTimeMillis()
        val endAt = now + Constants.DUEL_DURATION_DAYS * 24L * 60 * 60 * 1000

        val allUids = (listOf(challengerUid) + inviteUids).distinct()
        for (uid in allUids) if (hasActiveDuel(uid)) return null

        val participants = mutableListOf(
            mapOf("uid" to challengerUid, "displayName" to challengerName,
                "photoUrl" to challengerPhoto, "steps" to 0L,
                "joinedAt" to now, "hasAccepted" to true)
        )
        // Diger user-lərin adını bilmiriksə uid ilə saxlayırıq, qəbul edəndə dolacaq
        inviteUids.forEach { uid ->
            participants.add(mapOf("uid" to uid, "displayName" to uid,
                "photoUrl" to null, "steps" to 0L,
                "joinedAt" to now, "hasAccepted" to false))
        }

        val duel = hashMapOf(
            "type" to DuelType.GROUP.name,
            "title" to title.ifBlank { "Qrup Düellosu" },
            "challengerUid" to challengerUid,
            "challengerName" to challengerName,
            "challengerPhoto" to challengerPhoto,
            "participantUids" to allUids,
            "participants" to participants,
            "startAt" to now,
            "endAt" to endAt,
            "status" to DuelStatus.PENDING.name,
            "createdAt" to now
        )
        val ref = db.collection("duels").add(duel).await()
        return ref.id
    }

    /**
     * Düello sorğusunu qəbul edir (1v1).
     */
    suspend fun acceptDuel(duelId: String, uid: String): Boolean {
        return updateParticipant(duelId, uid) { data ->
            val list = (data["participants"] as? List<Map<String, Any>>)?.toMutableList()
                ?: return@updateParticipant null
            val updated = list.map { p ->
                if ((p["uid"] as? String) == uid) p.toMutableMap().apply {
                    this["hasAccepted"] = true
                } else p
            }
            data + ("participants" to updated)
        }.let { ok ->
            if (ok) {
                db.collection("duels").document(duelId)
                    .update("status", DuelStatus.ACTIVE.name).await()
                true
            } else false
        }
    }

    suspend fun declineDuel(duelId: String) {
        db.collection("duels").document(duelId)
            .update("status", DuelStatus.DECLINED.name).await()
    }

    suspend fun withdrawDuel(duelId: String) {
        db.collection("duels").document(duelId)
            .update("status", DuelStatus.WITHDRAWN.name).await()
    }

    /**
     * İstifadəçinin addım snapshot-ını duel iştirakçıları siyahısında yeniləyir.
     * StepCounterService hər 5 dəqiqədən bir çağırır.
     */
    suspend fun updateMyStepSnapshots(uid: String, steps: Long) {
        val active = db.collection("duels")
            .whereArrayContains("participantUids", uid)
            .whereEqualTo("status", DuelStatus.ACTIVE.name)
            .get().await()
        for (doc in active.documents) {
            val data = doc.data ?: continue
            val list = (data["participants"] as? List<Map<String, Any>>)?.toMutableList()
                ?: continue
            var changed = false
            val updated = list.map { p ->
                if ((p["uid"] as? String) == uid) {
                    changed = true
                    p.toMutableMap().apply { this["steps"] = steps }
                } else p
            }
            if (changed) {
                db.collection("duels").document(doc.id).update("participants", updated).await()
                // Vaxt bitibsə qalibi seç
                val endAt = (data["endAt"] as? Long) ?: continue
                if (System.currentTimeMillis() >= endAt) {
                    finishDuel(doc.id)
                }
            }
        }
    }

    /**
     * Düello bitir — ən çox addım atan iştirakçı qalib olur.
     */
    private suspend fun finishDuel(duelId: String) {
        val doc = db.collection("duels").document(duelId).get().await()
        val data = doc.data ?: return
        if ((data["status"] as? String) == DuelStatus.FINISHED.name) return
        val list = (data["participants"] as? List<Map<String, Any>>).orEmpty()
        val winner = list.maxByOrNull { (it["steps"] as? Long) ?: 0L }
        val winnerUid = winner?.get("uid") as? String
        db.collection("duels").document(duelId).update(
            mapOf(
                "status" to DuelStatus.FINISHED.name,
                "winnerUid" to winnerUid
            )
        ).await()
    }

    private suspend fun updateParticipant(
        duelId: String,
        uid: String,
        transform: (Map<String, Any?>) -> Map<String, Any?>?
    ): Boolean {
        val doc = db.collection("duels").document(duelId).get().await()
        val data = doc.data ?: return false
        val updated = transform(data) ?: return false
        db.collection("duels").document(duelId).set(updated).await()
        return true
    }

    /**
     * Aktiv düelloları izləyir.
     */
    fun observeActiveDuels(uid: String): Flow<List<Duel>> = callbackFlow {
        val reg = db.collection("duels")
            .whereArrayContains("participantUids", uid)
            .whereEqualTo("status", DuelStatus.ACTIVE.name)
            .orderBy("endAt", Query.Direction.ASCENDING)
            .addSnapshotListener { snap, err ->
                if (err != null) {
                    Timber.w(err, "observeActiveDuels")
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                trySend(snap?.documents?.mapNotNull { it.toObject(Duel::class.java) } ?: emptyList())
            }
        awaitClose { reg.remove() }
    }

    /**
     * Sorğu (pending) düelloları izləyir — mənə gələn.
     */
    fun observePendingDuels(uid: String): Flow<List<Duel>> = callbackFlow {
        val reg = db.collection("duels")
            .whereArrayContains("participantUids", uid)
            .whereEqualTo("status", DuelStatus.PENDING.name)
            .addSnapshotListener { snap, err ->
                if (err != null) {
                    Timber.w(err, "observePendingDuels")
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                trySend(snap?.documents?.mapNotNull { it.toObject(Duel::class.java) } ?: emptyList())
            }
        awaitClose { reg.remove() }
    }

    /**
     * Bitmiş düelloları izləyir.
     */
    fun observeFinishedDuels(uid: String): Flow<List<Duel>> = callbackFlow {
        val reg = db.collection("duels")
            .whereArrayContains("participantUids", uid)
            .whereEqualTo("status", DuelStatus.FINISHED.name)
            .orderBy("endAt", Query.Direction.DESCENDING)
            .limit(50)
            .addSnapshotListener { snap, err ->
                if (err != null) {
                    Timber.w(err, "observeFinishedDuels")
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                trySend(snap?.documents?.mapNotNull { it.toObject(Duel::class.java) } ?: emptyList())
            }
        awaitClose { reg.remove() }
    }
}