package com.steptracker.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.appcompat.app.AppCompatDelegate
import com.google.firebase.FirebaseApp
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.steptracker.app.data.local.AppDatabase
import com.steptracker.app.data.local.FolderManager
import com.steptracker.app.data.repository.*
import timber.log.Timber

/**
 * StepTrackerApplication — global application class.
 *
 * Initialize Firebase, Timber, Room database and core repositories here.
 */
class StepTrackerApplication : Application() {

    // Repositories are singletons — AppCompatDelegate mode-u local prefs ilə idarə olunur.
    lateinit var folderManager: FolderManager
        private set
    lateinit var database: AppDatabase
        private set
    lateinit var authRepository: AuthRepository
        private set
    lateinit var stepRepository: StepRepository
        private set
    lateinit var friendRepository: FriendRepository
        private set
    lateinit var duelRepository: DuelRepository
        private set
    lateinit var messageRepository: MessageRepository
        private set
    lateinit var leaderboardRepository: LeaderboardRepository
        private set
    lateinit var broadcastRepository: BroadcastRepository
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        // Timber (logging)
        if (BuildConfig.DEBUG) Timber.plant(Timber.DebugTree())

        // Local data folder — yaradılır, silinibsə xəbərdarlıq üçün qeyd olunur
        folderManager = FolderManager(this)
        folderManager.ensureAppFolderExists()

        // Room database — yalnız local addım məlumatları üçün
        database = AppDatabase.getInstance(this)

        // Firebase init
        FirebaseApp.initializeApp(this)

        // App Check (optional security for Firestore)
        try {
            val appCheck = FirebaseAppCheck.getInstance()
            appCheck.installAppCheckProviderFactory(
                PlayIntegrityAppCheckProviderFactory.getInstance()
            )
        } catch (t: Throwable) {
            Timber.w(t, "AppCheck install failed (non-fatal)")
        }

        // Firestore offline cache
        val fs = FirebaseFirestore.getInstance()
        val settings = FirebaseFirestoreSettings.Builder()
            .setPersistenceEnabled(true)
            .setCacheSizeBytes(FirebaseFirestoreSettings.CACHE_SIZE_UNLIMITED)
            .build()
        fs.firestoreSettings = settings

        // Repositories
        authRepository = AuthRepository()
        stepRepository = StepRepository(this, database.stepDao())
        friendRepository = FriendRepository()
        duelRepository = DuelRepository()
        messageRepository = MessageRepository()
        leaderboardRepository = LeaderboardRepository()
        broadcastRepository = BroadcastRepository(this)

        // Theme — system default (light/dark)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)

        createNotificationChannels()
    }

    /**
     * Android 8+ üçün bütün notification kanallarını yaradır.
     */
    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = getSystemService(NotificationManager::class.java) ?: return

        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_STEP_SERVICE,
                "Addım sayğacı",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Arxa planda addım saymaq üçün davamlı bildiriş"
                setShowBadge(false)
            }
        )

        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_DUEL,
                "Düello xəbərdarlıqları",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Düello sorğuları və nəticələri"
            }
        )

        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_FRIEND,
                "Dostluq sorğuları",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Dostluq sorğuları və mesajlar"
            }
        )

        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_GENERAL,
                "Ümumi",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Ümumi bildirişlər"
            }
        )
    }

    companion object {
        const val CHANNEL_STEP_SERVICE = "step_service"
        const val CHANNEL_DUEL = "duel_channel"
        const val CHANNEL_FRIEND = "friend_channel"
        const val CHANNEL_GENERAL = "general_channel"

        @Volatile
        private var instance: StepTrackerApplication? = null

        fun get(): StepTrackerApplication =
            instance ?: throw IllegalStateException("Application not initialized")
    }
}