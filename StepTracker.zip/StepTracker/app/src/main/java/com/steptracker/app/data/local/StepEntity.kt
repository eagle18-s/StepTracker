package com.steptracker.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Gündəlik addım cəm record-u.
 *
 * @param dayKey "yyyy-MM-dd" formatında gün açarı
 * @param steps həmin gün üçün ümumi addım sayı
 * @param calories sərf olunan kalori (kcal)
 * @param distanceMeters gəzilən məsafə (metr)
 * @param activeMinutes aktiv dəqiqələr
 * @param elevationGainMeters GPS-dən yüksəklik qazanclı
 * @param updatedAt son yenilənmə vaxtı (millis)
 */
@Entity(tableName = "daily_steps", primaryKeys = ["dayKey"])
data class StepEntity(
    val dayKey: String,
    val steps: Int,
    val calories: Double,
    val distanceMeters: Double,
    val activeMinutes: Int,
    val elevationGainMeters: Double = 0.0,
    val sensorSource: String = "TYPE_STEP_COUNTER",
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * Step sensor sessionu — service hər başladılanda / dayandırılanda bir session yaranır.
 */
@Entity(tableName = "step_sessions")
data class StepSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionStart: Long,
    val sessionEnd: Long?,
    val startSteps: Int,
    val endSteps: Int?,
    val stepsDelta: Int,
    val source: String  // "google_fit" | "hardware_sensor"
)