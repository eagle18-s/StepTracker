package com.steptracker.app.ui.chat

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.steptracker.app.StepTrackerApplication
import com.steptracker.app.databinding.FragmentChatListBinding
import com.steptracker.app.model.Conversation
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class ChatListFragment : Fragment() {

    private var _binding: FragmentChatListBinding? = null
    private val binding get() = _binding!!
    private val viewModel: ChatListViewModel by viewModels()
    private lateinit var adapter: ConversationsAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View {
        _binding = FragmentChatListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val app = requireActivity().application as StepTrackerApplication

        adapter = ConversationsAdapter { conv ->
            val otherUid = conv.participants.firstOrNull { it != (app.authRepository.currentUid() ?: "") } ?: return@ConversationsAdapter
            val intent = Intent(requireContext(), ChatActivity::class.java)
                .putExtra("friendUid", otherUid)
                .putExtra("conversationId", conv.id)
            startActivity(intent)
        }
        binding.recycler.layoutManager = LinearLayoutManager(requireContext())
        binding.recycler.adapter = adapter

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.conversations.collectLatest { list ->
                adapter.submitList(list)
                binding.emptyView.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            }
        }

        viewModel.load(app)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}