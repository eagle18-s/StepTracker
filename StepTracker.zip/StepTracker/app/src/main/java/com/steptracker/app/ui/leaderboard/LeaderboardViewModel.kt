package com.steptracker.app.ui.leaderboard

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.steptracker.app.StepTrackerApplication
import com.steptracker.app.model.LeaderboardEntry
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class LeaderboardViewModel(app: Application) : AndroidViewModel(app) {

    private val _entries = MutableStateFlow<List<LeaderboardEntry>>(emptyList())
    val entries: StateFlow<List<LeaderboardEntry>> = _entries.asStateFlow()

    private var tabIndex: Int = 0  // 0 = friends, 1 = global
    private var uid: String? = null
    private var friendUids: List<String> = emptyList()

    fun switchTab(idx: Int) {
        tabIndex = idx
        val app = getApplication<StepTrackerApplication>()
        load(app)
    }

    fun load(app: StepTrackerApplication) {
        uid = app.authRepository.currentUid() ?: return
        viewModelScope.launch {
            // Dostları izləyirik ki, dost tab-ı həmişə aktual olsun
            app.friendRepository.observeFriends(uid!!).collectLatest { friends ->
                friendUids = friends.map { it.uid }
                val list = if (tabIndex == 0) {
                    app.leaderboardRepository.friendsLeaderboard(uid!!, friendUids)
                } else {
                    app.leaderboardRepository.globalLeaderboard(100)
                }
                _entries.value = list
            }
        }
    }
}