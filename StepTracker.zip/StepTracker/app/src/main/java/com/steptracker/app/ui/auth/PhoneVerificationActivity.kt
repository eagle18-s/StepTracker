package com.steptracker.app.ui.auth

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.firebase.FirebaseException
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthProvider
import com.steptracker.app.R
import com.steptracker.app.StepTrackerApplication
import com.steptracker.app.databinding.ActivityPhoneVerificationBinding
import kotlinx.coroutines.launch
import timber.log.Timber
import java.util.concurrent.TimeUnit

/**
 * Telefon nömrəsi doğrulaması — Firebase Phone Auth istifadə edir.
 *
 * Addımlar:
 *  1) İstifadəçi ölkə kodu + nömrə daxil edir
 *  2) "Kod göndər" düyməsi → Firebase SMS göndərir
 *  3) SMS-dən gələn 6 rəqəmli kodu daxil edir
 *  4) Doğrulama → ProfileSetupActivity
 */
class PhoneVerificationActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPhoneVerificationBinding
    private var verificationId: String? = null
    private var resendToken: PhoneAuthProvider.ForceResendingToken? = null
    private var pendingPhone: String = ""

    private val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

        override fun onVerificationCompleted(credential: PhoneAuthCredential) {
            // SMS auto-read (bəzi cihazlarda)
            binding.codeInput.setText(credential.smsCode ?: "")
            verifyCode(credential.smsCode ?: "")
        }

        override fun onVerificationFailed(e: FirebaseException) {
            Timber.w(e, "Phone verification failed")
            Toast.makeText(this@PhoneVerificationActivity,
                getString(R.string.phone_error, e.localizedMessage ?: ""),
                Toast.LENGTH_LONG).show()
            binding.progressBar.visibility = View.GONE
            binding.btnSendCode.isEnabled = true
        }

        override fun onCodeSent(id: String, token: PhoneAuthProvider.ForceResendingToken) {
            verificationId = id
            resendToken = token
            binding.progressBar.visibility = View.GONE
            binding.btnSendCode.isEnabled = true
            binding.codeGroup.visibility = View.VISIBLE
            binding.btnVerifyCode.isEnabled = true
            binding.resendText.visibility = View.VISIBLE
            Toast.makeText(this@PhoneVerificationActivity,
                R.string.phone_code_sent, Toast.LENGTH_SHORT).show()
        }

        override fun onCodeAutoRetrievalTimeOut(id: String) {
            super.onCodeAutoRetrievalTimeOut(id)
            binding.progressBar.visibility = View.GONE
            binding.btnSendCode.isEnabled = true
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPhoneVerificationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSendCode.setOnClickListener { sendCode() }
        binding.btnVerifyCode.setOnClickListener { verifyCode(binding.codeInput.text.toString()) }
        binding.resendText.setOnClickListener { resendCode() }

        binding.codeInput.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                binding.btnVerifyCode.isEnabled = (s?.length ?: 0) >= 6
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    private fun sendCode() {
        val cc = binding.ccInput.text.toString().trim()
        val num = binding.phoneInput.text.toString().trim()
        if (num.length < 6) {
            Toast.makeText(this, R.string.phone_invalid, Toast.LENGTH_SHORT).show()
            return
        }
        pendingPhone = "+$cc$num"
        binding.btnSendCode.isEnabled = false
        binding.progressBar.visibility = View.VISIBLE
        (application as StepTrackerApplication).authRepository.startPhoneVerification(
            this, pendingPhone, callbacks
        )
    }

    private fun resendCode() {
        if (pendingPhone.isEmpty()) return
        val token = resendToken ?: return
        binding.btnSendCode.isEnabled = false
        binding.progressBar.visibility = View.VISIBLE
        (application as StepTrackerApplication).authRepository.resendPhoneCode(
            this, pendingPhone, token, callbacks
        )
    }

    private fun verifyCode(code: String) {
        val id = verificationId ?: return
        if (code.length < 6) {
            Toast.makeText(this, R.string.code_invalid, Toast.LENGTH_SHORT).show()
            return
        }
        binding.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch {
            val user = (application as StepTrackerApplication)
                .authRepository.verifyPhoneCode(id, code)
            binding.progressBar.visibility = View.GONE
            if (user != null) {
                startActivity(Intent(this@PhoneVerificationActivity, ProfileSetupActivity::class.java))
                finish()
            } else {
                Toast.makeText(this@PhoneVerificationActivity,
                    R.string.code_wrong, Toast.LENGTH_SHORT).show()
            }
        }
    }
}