package com.steptracker.app.util

import kotlin.math.max
import kotlin.math.min

/**
 * Kalori hesablama util klassı.
 *
 * Formula:
 *  kcal = steps * bodyWeight(kg) * 0.0005
 *
 * Plus elevation correction based on GPS (hills add ~30% calories).
 */
object CalorieCalculator {

    /**
     * Sadə kalori hesablaması (steps * weight * coefficient).
     *
     * @param steps addım sayı
     * @param weightKg istifadəçi çəkisi (kg)
     * @return sərf olunan kalori (kcal)
     */
    fun calculate(steps: Int, weightKg: Double): Double {
        val safeWeight = if (weightKg <= 0.0) Constants.DEFAULT_USER_WEIGHT_KG else weightKg
        return steps * safeWeight * Constants.KCAL_PER_STEP_PER_KG
    }

    /**
     * GPS əsaslı düzəlişli kalori (yüksəklik dəyişikliyinə görə).
     *
     * @param steps addım sayı
     * @param weightKg çəki
     * @param elevationGainMeters GPS-dən hesablanmış yüksəklik qazanclı (metr)
     * @return kcal
     */
    fun calculateWithElevation(steps: Int, weightKg: Double, elevationGainMeters: Double): Double {
        val base = calculate(steps, weightKg)
        // Hər 10 metr yüksəklik qazanclı ≈ +1 kcal/kg (sadələşdirilmiş)
        val elevationBonus = (elevationGainMeters / 10.0) * (weightKg.coerceAtLeast(40.0))
        return base + elevationBonus
    }

    /**
     * Addım uzunluğu (sm) — hündürlüyə görə adaptiv.
     */
    fun strideLengthCm(heightCm: Double, isMale: Boolean): Double {
        val h = if (heightCm <= 0.0) Constants.DEFAULT_USER_HEIGHT_CM else heightCm
        // Empirical formulas: male = 0.415*H, female = 0.413*H
        val factor = if (isMale) 0.415 else 0.413
        return h * factor
    }

    /**
     * Məsafə (metr) hesablaması.
     */
    fun distanceMeters(steps: Int, heightCm: Double, isMale: Boolean): Double {
        val stride = strideLengthCm(heightCm, isMale) / 100.0  // metres
        return steps * stride
    }

    /**
     * Dəqiqə sürəti (km/h) — istifadəçinin addım tempinə görə.
     * Default = orta piyada sürəti 4.8 km/h.
     */
    fun defaultSpeedKmh(): Double = 4.8

    /**
     * Aktiv dəqiqələr — orta sürətlə addım sayından hesablanır.
     * ~100 addım = ~1 dəqiqə aktiv (təxmini).
     */
    fun activeMinutes(steps: Int): Int {
        return (steps / 100).coerceAtLeast(0)
    }

    /**
     * Günlük məqsədə çatma faizi (0..100+).
     */
    fun goalProgressPercent(steps: Int, goal: Int): Int {
        if (goal <= 0) return 0
        return ((steps.toFloat() / goal.toFloat()) * 100f).toInt().coerceAtLeast(0)
    }

    /**
     * Kalorini 0..max arasında clamp etmək (UI üçün).
     */
    fun clampKcal(value: Double, max: Double = 5000.0): Double {
        return min(max, max(0.0, value))
    }
}