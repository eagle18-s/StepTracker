package com.steptracker.app.data.repository

import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.steptracker.app.model.Friend
import com.steptracker.app.model.FriendRequest
import com.steptracker.app.model.FriendStatus
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import timber.log.Timber

/**
 * Dostluq sistemi — Firestore "friendRequests" və "friends" collection-ları.
 */
class FriendRepository {

    private val db = FirebaseFirestore.getInstance()

    /**
     * Dostluq sorğusu göndərir.
     * @param toUid hədəfin uid-i
     */
    suspend fun sendFriendRequest(fromUid: String, fromName: String, fromPhoto: String?,
                                  toUid: String, toName: String, message: String? = null): Boolean {
        // Dublikat sorğunun qarşısını al
        val existing = db.collection("friendRequests")
            .whereEqualTo("fromUid", fromUid)
            .whereEqualTo("toUid", toUid)
            .whereEqualTo("status", FriendStatus.PENDING_IN.name)
            .get().await()
        if (!existing.isEmpty) return false

        // Eyni zamanda qarşı tərəfdən sorğu varsa — avtomatik qəbul et
        val reverse = db.collection("friendRequests")
            .whereEqualTo("fromUid", toUid)
            .whereEqualTo("toUid", fromUid)
            .whereEqualTo("status", FriendStatus.PENDING_IN.name)
            .get().await()
        if (!reverse.isEmpty) {
            val req = reverse.documents.first()
            acceptFriendRequest(req.id, fromUid, fromName, fromPhoto, toUid, toName)
            return true
        }

        val req = FriendRequest(
            requestId = "",
            fromUid = fromUid,
            fromName = fromName,
            fromPhoto = fromPhoto,
            toUid = toUid,
            toName = toName,
            message = message
        )
        db.collection("friendRequests").add(req).await()
        return true
    }

    /**
     * Sorğunu qəbul edir — hər iki istifadəçinin "friends" subcollection-una əlavə edir.
     */
    suspend fun acceptFriendRequest(requestId: String, fromUid: String, fromName: String,
                                    fromPhoto: String?, toUid: String, toName: String) {
        db.collection("friendRequests").document(requestId)
            .update("status", FriendStatus.ACCEPTED.name).await()
        db.collection("users").document(toUid)
            .collection("friends").document(fromUid)
            .set(mapOf(
                "uid" to fromUid,
                "displayName" to fromName,
                "photoUrl" to fromPhoto,
                "since" to System.currentTimeMillis()
            )).await()
        db.collection("users").document(fromUid)
            .collection("friends").document(toUid)
            .set(mapOf(
                "uid" to toUid,
                "displayName" to toName,
                "photoUrl" to null,
                "since" to System.currentTimeMillis()
            )).await()
    }

    suspend fun declineFriendRequest(requestId: String) {
        db.collection("friendRequests").document(requestId)
            .update("status", FriendStatus.NONE.name).await()
    }

    suspend fun removeFriend(uid: String, friendUid: String) {
        db.collection("users").document(uid).collection("friends").document(friendUid).delete().await()
        db.collection("users").document(friendUid).collection("friends").document(uid).delete().await()
    }

    /**
     * Gələn dostluq sorğularını izləyir.
     */
    fun observeIncomingRequests(uid: String): Flow<List<FriendRequest>> = callbackFlow {
        val reg = db.collection("friendRequests")
            .whereEqualTo("toUid", uid)
            .whereEqualTo("status", FriendStatus.PENDING_IN.name)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snap, err ->
                if (err != null) {
                    Timber.w(err, "observeIncomingRequests")
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snap?.documents?.mapNotNull { doc ->
                    val data = doc.data ?: return@mapNotNull null
                    FriendRequest(
                        requestId = doc.id,
                        fromUid = data["fromUid"] as? String ?: return@mapNotNull null,
                        fromName = data["fromName"] as? String ?: "",
                        fromPhoto = data["fromPhoto"] as? String,
                        toUid = data["toUid"] as? String ?: "",
                        toName = data["toName"] as? String ?: "",
                        message = data["message"] as? String,
                        createdAt = (data["createdAt"] as? Long) ?: 0L,
                        status = FriendStatus.PENDING_IN
                    )
                } ?: emptyList()
                trySend(list)
            }
        awaitClose { reg.remove() }
    }

    /**
     * Dostlar siyahısını izləyir.
     */
    fun observeFriends(uid: String): Flow<List<Friend>> = callbackFlow {
        val reg = db.collection("users").document(uid)
            .collection("friends")
            .orderBy("since", Query.Direction.DESCENDING)
            .addSnapshotListener { snap, err ->
                if (err != null) {
                    Timber.w(err, "observeFriends")
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snap?.documents?.mapNotNull { doc ->
                    val data = doc.data ?: return@mapNotNull null
                    Friend(
                        uid = doc.id,
                        displayName = data["displayName"] as? String ?: "",
                        email = "",
                        photoUrl = data["photoUrl"] as? String,
                        status = FriendStatus.ACCEPTED
                    )
                } ?: emptyList()
                trySend(list)
            }
        awaitClose { reg.remove() }
    }

    /**
     * İstifadəçini email-ə görə axtarır (dostluq sorğusu üçün).
     */
    suspend fun findUserByEmail(email: String): Friend? {
        val snap = db.collection("users")
            .whereEqualTo("email", email.trim().lowercase())
            .limit(1).get().await()
        val doc = snap.documents.firstOrNull() ?: return null
        val data = doc.data ?: return null
        return Friend(
            uid = doc.id,
            displayName = data["displayName"] as? String ?: "",
            email = data["email"] as? String ?: "",
            photoUrl = data["photoUrl"] as? String
        )
    }

    suspend fun findUserByUid(uid: String): Friend? {
        val doc = db.collection("users").document(uid).get().await()
        if (!doc.exists()) return null
        val data = doc.data ?: return null
        return Friend(
            uid = doc.id,
            displayName = data["displayName"] as? String ?: "",
            email = data["email"] as? String ?: "",
            photoUrl = data["photoUrl"] as? String
        )
    }
}