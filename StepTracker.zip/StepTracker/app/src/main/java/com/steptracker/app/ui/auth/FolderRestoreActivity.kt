package com.steptracker.app.ui.auth

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.steptracker.app.R
import com.steptracker.app.StepTrackerApplication
import com.steptracker.app.databinding.ActivityFolderRestoreBinding
import com.steptracker.app.ui.SplashActivity

/**
 * FolderRestoreActivity — istifadəçi StepTrackerData qovluğunu manual sildikdə
 * göstərilən xəbərdarlıq ekranı.
 *
 * İstifadəçi "Yeni qovluq yarat" düyməsini basdıqda avtomatik olaraq
 * FolderManager tərəfindən yeni folder yaradılır və Splash-a qayıdılır.
 */
class FolderRestoreActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFolderRestoreBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFolderRestoreBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.tvWarning.text = getString(R.string.folder_deleted_warning)
        binding.tvHint.text = getString(R.string.folder_deleted_hint)
        binding.btnRestore.setOnClickListener {
            val app = application as StepTrackerApplication
            app.folderManager.ensureAppFolderExists()
            app.folderManager.clearDeletedFlag()
            startActivity(Intent(this, SplashActivity::class.java))
            finish()
        }
        binding.btnCancel.setOnClickListener {
            finishAffinity()
        }
    }
}