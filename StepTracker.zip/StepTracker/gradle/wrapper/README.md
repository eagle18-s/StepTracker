# Gradle wrapper faylları

`gradlew`, `gradlew.bat` və `gradle-wrapper.jar` faylları Android Studio-nun
ilk açılışında avtomatik olaraq yaradılacaq (File → Sync with Gradle Files).

Əgər manual əlavə etmək istəyirsinizsə:

```bash
cd StepTracker
gradle wrapper --gradle-version 8.2
```

və ya https://services.gradle.org/distributions/gradle-8.2-bin.zip endirin
və `gradle/wrapper/` qovluğunda aşağıdakıları yerləşdirin:
- `gradle-wrapper.jar` (gradle-in özündən götürün)
- `gradle-wrapper.properties` (artıq var)
- `gradlew` (Unix script)
- `gradlew.bat` (Windows script)