package com.broadcast.app.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.broadcast.app.R
import com.broadcast.app.data.BroadcastRepository
import com.broadcast.app.databinding.ActivityNewBroadcastBinding
import com.broadcast.app.model.BroadcastMessage
import kotlinx.coroutines.launch

class NewBroadcastActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNewBroadcastBinding
    private val repo by lazy { BroadcastRepository(applicationContext) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNewBroadcastBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.toolbar.setNavigationOnClickListener { finish() }

        binding.btnSend.setOnClickListener { publish() }
    }

    private fun publish() {
        val title = binding.titleInput.text.toString().trim()
        val body = binding.bodyInput.text.toString().trim()
        if (title.isEmpty() || body.isEmpty()) {
            Toast.makeText(this, R.string.fill_all, Toast.LENGTH_SHORT).show()
            return
        }
        val msg = BroadcastMessage(
            title = title,
            body = body,
            imageUrl = binding.imageUrlInput.text.toString().trim().ifBlank { null },
            actionUrl = binding.actionUrlInput.text.toString().trim().ifBlank { null },
            priority = binding.prioritySlider.value.toInt()
        )
        binding.btnSend.isEnabled = false
        lifecycleScope.launch {
            repo.publish(msg)
            Toast.makeText(this@NewBroadcastActivity, R.string.broadcast_sent, Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}