package com.broadcast.app.data

import android.content.Context
import com.broadcast.app.model.BroadcastMessage
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import timber.log.Timber

/**
 * BroadcastRepository — Firebase Firestore-da "broadcasts" collection-u.
 *
 * Companion app bütün istifadəçilərə göndəriləcək mesajları burada saxlayır.
 * Əsas StepTracker app-ı isə Firestore-dan real-time dinləyə bilər və ya
 * shared storage-dən oxuya bilər.
 */
class BroadcastRepository(private val context: Context) {

    private val db = FirebaseFirestore.getInstance()
    private val writer = BroadcastWriter(context)

    fun observeAll(): Flow<List<BroadcastMessage>> = callbackFlow {
        val reg = db.collection("broadcasts")
            .orderBy("sentAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snap, err ->
                if (err != null) {
                    Timber.w(err, "observeAll")
                    trySend(emptyList()); return@addSnapshotListener
                }
                trySend(snap?.documents?.mapNotNull { it.toObject(BroadcastMessage::class.java) } ?: emptyList())
            }
        awaitClose { reg.remove() }
    }

    suspend fun publish(msg: BroadcastMessage) {
        // Firestore-a da yaz (cross-device sync üçün)
        try {
            db.collection("broadcasts").document(msg.id).set(msg).await()
        } catch (t: Throwable) {
            Timber.w(t, "firestore publish failed")
        }
        // Shared storage-ə də yaz (offline fallback)
        writer.addMessage(msg)
    }

    suspend fun delete(id: String) {
        try { db.collection("broadcasts").document(id).delete().await() }
        catch (t: Throwable) { Timber.w(t, "delete failed") }
        writer.deleteMessage(id)
    }

    suspend fun readFromLocal(): List<BroadcastMessage> = writer.readAll()
}