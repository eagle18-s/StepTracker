package com.broadcast.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.broadcast.app.databinding.ActivityBroadcastListBinding
import com.broadcast.app.databinding.ItemBroadcastBinding
import com.broadcast.app.model.BroadcastMessage
import com.broadcast.app.data.BroadcastRepository
import com.broadcast.app.util.DateUtils
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class BroadcastListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBroadcastListBinding
    private val repo by lazy { BroadcastRepository(applicationContext) }
    private val adapter = BroadcastAdapter { msg ->
        repo.delete(msg.id)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBroadcastListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.title = "Broadcast İdarəsi"
        binding.toolbar.subtitle = FirebaseAuth.getInstance().currentUser?.email
        binding.toolbar.setNavigationOnClickListener { finish() }

        binding.recycler.layoutManager = LinearLayoutManager(this)
        binding.recycler.adapter = adapter

        binding.fabNew.setOnClickListener {
            startActivity(Intent(this, NewBroadcastActivity::class.java))
        }

        lifecycleScope.launch {
            repo.observeAll().collectLatest { list ->
                adapter.submitList(list)
            }
        }
    }
}

class BroadcastAdapter(
    private val onDelete: (BroadcastMessage) -> Unit
) : RecyclerView.Adapter<BroadcastAdapter.VH>() {

    private val items = mutableListOf<BroadcastMessage>()

    fun submitList(list: List<BroadcastMessage>) {
        items.clear(); items.addAll(list); notifyDataSetChanged()
    }

    class VH(val b: ItemBroadcastBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemBroadcastBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val m = items[position]
        holder.b.title.text = m.title
        holder.b.body.text = m.body
        holder.b.time.text = DateUtilsKt.displayDateTime(m.sentAt)
        holder.b.btnDelete.setOnClickListener { onDelete(m) }
    }

    override fun getItemCount(): Int = items.size
}