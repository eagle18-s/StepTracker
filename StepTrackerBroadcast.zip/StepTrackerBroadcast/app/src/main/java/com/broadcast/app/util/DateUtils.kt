package com.broadcast.app.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object DateUtilsKt {
    private val f = SimpleDateFormat("d MMM, HH:mm", Locale("az"))
    fun displayDateTime(t: Long): String = f.format(Date(t))
}