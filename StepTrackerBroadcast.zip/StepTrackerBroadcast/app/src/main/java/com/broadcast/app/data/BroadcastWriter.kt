package com.broadcast.app.data

import android.content.Context
import com.broadcast.app.model.BroadcastMessage
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.io.File

/**
 * BroadcastWriter — broadcast mesajlarını external storage-dəki
 * StepTrackerBroadcast/broadcast_messages.json faylına yazır.
 *
 * Əsas StepTracker app-ı bu faylı oxuyur. Shared storage pattern.
 */
class BroadcastWriter(private val context: Context) {

    private val gson = Gson()

    /**
     * Broadcast faylının yeri.
     */
    val broadcastFile: File
        get() {
            val root = android.os.Environment.getExternalStorageDirectory()
            val dir = File(root, "StepTrackerBroadcast")
            if (!dir.exists()) dir.mkdirs()
            return File(dir, "broadcast_messages.json")
        }

    /**
     * Aktiv (vaxtı keçməmiş) broadcast-ları oxu.
     */
    suspend fun readAll(): List<BroadcastMessage> = withContext(Dispatchers.IO) {
        try {
            val f = broadcastFile
            if (!f.exists()) return@withContext emptyList()
            val json = f.readText(Charsets.UTF_8)
            if (json.isBlank()) return@withContext emptyList()
            val type = object : TypeToken<List<BroadcastMessage>>() {}.type
            gson.fromJson(json, type) ?: emptyList()
        } catch (t: Throwable) {
            Timber.w(t, "readAll failed")
            emptyList()
        }
    }

    /**
     * Broadcast siyahısına yeni mesaj əlavə edib yenidən yaz.
     */
    suspend fun addMessage(msg: BroadcastMessage): Boolean = withContext(Dispatchers.IO) {
        try {
            val list = readAll().toMutableList()
            list.add(0, msg)  // Yeni mesajlar üstdə
            broadcastFile.writeText(gson.toJson(list))
            true
        } catch (t: Throwable) {
            Timber.w(t, "addMessage failed")
            false
        }
    }

    /**
     * Mesajı id-yə görə sil.
     */
    suspend fun deleteMessage(id: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val list = readAll().filter { it.id != id }
            broadcastFile.writeText(gson.toJson(list))
            true
        } catch (t: Throwable) {
            Timber.w(t, "deleteMessage failed")
            false
        }
    }

    /**
     * Bütün broadcast-ları sil.
     */
    suspend fun clearAll(): Boolean = withContext(Dispatchers.IO) {
        try {
            broadcastFile.writeText("[]")
            true
        } catch (t: Throwable) {
            Timber.w(t, "clearAll failed")
            false
        }
    }
}