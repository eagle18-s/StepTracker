package com.broadcast.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.broadcast.app.databinding.ActivityAuthBinding
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import timber.log.Timber

/**
 * AuthActivity — Broadcast app-ına admin Google hesabı ilə daxil olmaq.
 *
 * Real deploy-da yalnız sizin email-iniz üçün admin girişi aktiv olmalıdır.
 * Bunun üçün Firebase Auth + Firestore "admins" collection-undan yoxlama əlavə edin.
 */
class AuthActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAuthBinding

    private val signInLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        try {
            val account = task.getResult(ApiException::class.java)
            lifecycleScope.launch {
                val credential = GoogleAuthProvider.getCredential(account.idToken, null)
                FirebaseAuth.getInstance().signInWithCredential(credential).await()
                startActivity(Intent(this@AuthActivity, BroadcastListActivity::class.java))
                finish()
            }
        } catch (e: ApiException) {
            Timber.w(e, "Google Sign-In failed")
            binding.errorText.text = "Xəta: ${e.statusCode}"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAuthBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Əgər artıq daxil olubsa — keç
        if (FirebaseAuth.getInstance().currentUser != null) {
            startActivity(Intent(this, BroadcastListActivity::class.java))
            finish(); return
        }

        binding.btnGoogle.setOnClickListener {
            val gso = com.google.android.gms.auth.api.signin.GoogleSignInOptions.Builder(
                com.google.android.gms.auth.api.signin.GoogleSignInOptions.DEFAULT_SIGN_IN
            )
                .requestIdToken(getString(com.broadcast.app.R.string.default_web_client_id))
                .requestEmail()
                .build()
            val client = GoogleSignIn.getClient(this, gso)
            signInLauncher.launch(client.signInIntent)
        }
    }
}