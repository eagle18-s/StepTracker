package com.broadcast.app.model

import java.util.UUID

data class BroadcastMessage(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val body: String,
    val imageUrl: String? = null,
    val actionUrl: String? = null,
    val priority: Int = 0,
    val sentAt: Long = System.currentTimeMillis(),
    val expiresAt: Long? = null
)